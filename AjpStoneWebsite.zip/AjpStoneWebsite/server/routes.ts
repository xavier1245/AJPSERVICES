import type { Express } from "express";
import { createServer, type Server } from "http";

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Contact form endpoint
  app.post("/api/contact", (req, res) => {
    const { name, email, phone, projectType, message } = req.body;
    
    // Basic validation
    if (!name || !email || !message) {
      return res.status(400).json({ 
        message: "Name, email, and message are required" 
      });
    }

    // For now, just log the contact form submission
    console.log("Contact form submission:", { name, email, phone, projectType, message });
    
    res.json({ 
      message: "Contact form submitted successfully",
      success: true 
    });
  });

  // Appointment booking endpoint
  app.post("/api/appointment", (req, res) => {
    const { name, email, phone, date, time, projectType } = req.body;
    
    if (!name || !email || !phone || !date || !time) {
      return res.status(400).json({ 
        message: "All fields are required for appointment booking" 
      });
    }

    console.log("Appointment booking:", { name, email, phone, date, time, projectType });
    
    res.json({ 
      message: "Appointment booked successfully",
      success: true 
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
