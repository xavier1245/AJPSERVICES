// Enhanced Service Worker for PWA functionality
const CACHE_NAME = 'ajp-services-v2';
const STATIC_CACHE = 'ajp-static-v2';
const DYNAMIC_CACHE = 'ajp-dynamic-v2';
const IMAGE_CACHE = 'ajp-images-v2';

// Files to cache immediately
const staticAssets = [
  '/',
  '/manifest.json',
  '/offline.html',
  // Core app files will be cached automatically by Vite
];

// Cache strategies
const cacheStrategies = {
  images: {
    cacheName: IMAGE_CACHE,
    maxEntries: 100,
    maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
  },
  api: {
    cacheName: DYNAMIC_CACHE,
    maxAge: 5 * 60 * 1000, // 5 minutes
  },
  static: {
    cacheName: STATIC_CACHE,
    maxAge: 24 * 60 * 60 * 1000, // 1 day
  }
};

// Install event
self.addEventListener('install', (event) => {
  event.waitUntil(
    Promise.all([
      caches.open(STATIC_CACHE).then(cache => cache.addAll(staticAssets)),
      self.skipWaiting()
    ])
  );
});

// Activate event
self.addEventListener('activate', (event) => {
  event.waitUntil(
    Promise.all([
      // Clean up old caches
      caches.keys().then(cacheNames => {
        return Promise.all(
          cacheNames
            .filter(cacheName => 
              cacheName.startsWith('ajp-') && 
              ![CACHE_NAME, STATIC_CACHE, DYNAMIC_CACHE, IMAGE_CACHE].includes(cacheName)
            )
            .map(cacheName => caches.delete(cacheName))
        );
      }),
      self.clients.claim()
    ])
  );
});

// Fetch event with smart caching
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests and chrome-extension requests
  if (request.method !== 'GET' || url.protocol === 'chrome-extension:') {
    return;
  }

  // Handle different types of requests
  if (request.destination === 'image') {
    event.respondWith(handleImageRequest(request));
  } else if (url.pathname.startsWith('/api/')) {
    event.respondWith(handleApiRequest(request));
  } else if (url.pathname.includes('.')) {
    // Static assets
    event.respondWith(handleStaticRequest(request));
  } else {
    // Navigation requests
    event.respondWith(handleNavigationRequest(request));
  }
});

// Image caching strategy - Cache first, then network
async function handleImageRequest(request) {
  try {
    const cache = await caches.open(IMAGE_CACHE);
    const cachedResponse = await cache.match(request);
    
    if (cachedResponse) {
      return cachedResponse;
    }

    const networkResponse = await fetch(request);
    if (networkResponse.ok) {
      cache.put(request, networkResponse.clone());
    }
    return networkResponse;
  } catch (error) {
    console.warn('Image fetch failed:', error);
    // Return a placeholder image or cached version
    const cache = await caches.open(IMAGE_CACHE);
    return cache.match(request) || new Response('', { status: 404 });
  }
}

// API caching strategy - Network first, then cache
async function handleApiRequest(request) {
  try {
    const cache = await caches.open(DYNAMIC_CACHE);
    
    // Try network first
    const networkResponse = await fetch(request);
    if (networkResponse.ok) {
      cache.put(request, networkResponse.clone());
      return networkResponse;
    }
    
    // Fallback to cache
    return cache.match(request) || networkResponse;
  } catch (error) {
    // Network failed, try cache
    const cache = await caches.open(DYNAMIC_CACHE);
    const cachedResponse = await cache.match(request);
    
    if (cachedResponse) {
      return cachedResponse;
    }
    
    throw error;
  }
}

// Static assets - Cache first
async function handleStaticRequest(request) {
  try {
    const cache = await caches.open(STATIC_CACHE);
    const cachedResponse = await cache.match(request);
    
    if (cachedResponse) {
      return cachedResponse;
    }

    const networkResponse = await fetch(request);
    if (networkResponse.ok) {
      cache.put(request, networkResponse.clone());
    }
    return networkResponse;
  } catch (error) {
    const cache = await caches.open(STATIC_CACHE);
    return cache.match(request) || new Response('', { status: 404 });
  }
}

// Navigation requests - Network first, fallback to cache, then offline page
async function handleNavigationRequest(request) {
  try {
    // Try network first
    const networkResponse = await fetch(request);
    return networkResponse;
  } catch (error) {
    // Try cache
    const cache = await caches.open(STATIC_CACHE);
    const cachedResponse = await cache.match(request);
    
    if (cachedResponse) {
      return cachedResponse;
    }
    
    // Return offline page
    return cache.match('/offline.html') || 
           cache.match('/') || 
           new Response('Offline', { status: 503 });
  }
}

// Background sync for form submissions
self.addEventListener('sync', (event) => {
  if (event.tag === 'contact-form') {
    event.waitUntil(syncContactForm());
  }
});

async function syncContactForm() {
  // Handle offline form submissions when back online
  const data = await getStoredFormData();
  if (data) {
    try {
      await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      await clearStoredFormData();
    } catch (error) {
      console.error('Failed to sync form data:', error);
    }
  }
}

// Helper functions for IndexedDB operations
async function getStoredFormData() {
  // Implement IndexedDB retrieval
  return null;
}

async function clearStoredFormData() {
  // Implement IndexedDB cleanup
}