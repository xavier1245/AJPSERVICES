import { useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { trackPageView } from '../lib/analytics';

export const useAnalytics = () => {
  const [location] = useLocation();
  const prevLocationRef = useRef<string>(location);
  
  useEffect(() => {
    if (location !== prevLocationRef.current) {
      // Delay tracking to ensure page title is updated
      setTimeout(() => {
        trackPageView(location);
      }, 100);
      
      prevLocationRef.current = location;
    }
  }, [location]);
};