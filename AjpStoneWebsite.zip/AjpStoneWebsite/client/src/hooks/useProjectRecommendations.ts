import { useState, useEffect } from 'react';

interface Project {
  id: number;
  title: string;
  category: string;
  location: string;
  year: string;
  image: string;
  description: string;
}

interface ViewHistory {
  projectId: number;
  timestamp: number;
  category: string;
  location: string;
}

const STORAGE_KEY = 'ajp_project_views';
const MAX_HISTORY = 50;

export const useProjectRecommendations = () => {
  const [viewHistory, setViewHistory] = useState<ViewHistory[]>([]);

  // Load view history from localStorage
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setViewHistory(JSON.parse(stored));
      } catch (error) {
        console.error('Error loading view history:', error);
      }
    }
  }, []);

  // Save view history to localStorage
  const saveHistory = (history: ViewHistory[]) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
    } catch (error) {
      console.error('Error saving view history:', error);
    }
  };

  // Track a project view
  const trackProjectView = (project: Project) => {
    const newView: ViewHistory = {
      projectId: project.id,
      timestamp: Date.now(),
      category: project.category,
      location: project.location
    };

    setViewHistory(prev => {
      // Remove duplicate views of the same project
      const filtered = prev.filter(view => view.projectId !== project.id);
      
      // Add new view at the beginning
      const updated = [newView, ...filtered];
      
      // Keep only the most recent views
      const trimmed = updated.slice(0, MAX_HISTORY);
      
      saveHistory(trimmed);
      return trimmed;
    });
  };

  // Calculate recommendation score for a project
  const calculateRecommendationScore = (project: Project, history: ViewHistory[]): number => {
    if (history.length === 0) return 0;
    
    let score = 0;
    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;
    const oneWeek = 7 * oneDay;

    history.forEach((view, index) => {
      const recency = now - view.timestamp;
      const recencyWeight = recency < oneDay ? 1.0 : recency < oneWeek ? 0.7 : 0.3;
      const positionWeight = 1 - (index / history.length) * 0.5; // More recent views weighted higher

      // Category match
      if (view.category === project.category) {
        score += 3 * recencyWeight * positionWeight;
      }

      // Location proximity (same city/area)
      if (view.location.includes(project.location.split(',')[0]) || 
          project.location.includes(view.location.split(',')[0])) {
        score += 2 * recencyWeight * positionWeight;
      }

      // Year proximity (similar time period)
      const viewYear = parseInt(project.year);
      const historyYear = new Date(view.timestamp).getFullYear();
      if (Math.abs(viewYear - historyYear) <= 2) {
        score += 1 * recencyWeight * positionWeight;
      }
    });

    return score;
  };

  // Get recommended projects
  const getRecommendations = (allProjects: Project[], currentProjectId?: number, limit = 4): Project[] => {
    if (viewHistory.length === 0) {
      // If no history, return recent projects
      return allProjects
        .filter(p => currentProjectId ? p.id !== currentProjectId : true)
        .sort((a, b) => parseInt(b.year) - parseInt(a.year))
        .slice(0, limit);
    }

    // Calculate scores for all projects
    const scoredProjects = allProjects
      .filter(p => currentProjectId ? p.id !== currentProjectId : true)
      .map(project => ({
        ...project,
        score: calculateRecommendationScore(project, viewHistory)
      }))
      .sort((a, b) => b.score - a.score);

    // Return top recommendations
    return scoredProjects.slice(0, limit);
  };

  // Get category preferences based on view history
  const getCategoryPreferences = (): { [key: string]: number } => {
    const preferences: { [key: string]: number } = {};
    
    viewHistory.forEach((view, index) => {
      const weight = 1 - (index / viewHistory.length) * 0.5;
      preferences[view.category] = (preferences[view.category] || 0) + weight;
    });

    return preferences;
  };

  // Get location preferences
  const getLocationPreferences = (): { [key: string]: number } => {
    const preferences: { [key: string]: number } = {};
    
    viewHistory.forEach((view, index) => {
      const weight = 1 - (index / viewHistory.length) * 0.5;
      const location = view.location.split(',')[0].trim();
      preferences[location] = (preferences[location] || 0) + weight;
    });

    return preferences;
  };

  // Clear view history
  const clearHistory = () => {
    setViewHistory([]);
    localStorage.removeItem(STORAGE_KEY);
  };

  return {
    trackProjectView,
    getRecommendations,
    getCategoryPreferences,
    getLocationPreferences,
    clearHistory,
    viewHistory
  };
};