import { ArrowLeft, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useLanguage } from "@/contexts/LanguageContext";
import LanguageSelector from "@/components/LanguageSelector";
import ProjectRecommendations from "@/components/ProjectRecommendations";

const allProjects = [


  {
    id: 3,
    title: "Remodelación Casa Completa",
    description: "Proyecto integral de remodelación con múltiples espacios y diferentes tipos de piedra natural.",
    category: "Proyecto Integral",
    location: "Key Biscayne, Miami FL",
    year: "2024",
    image: "https://ajp-services.com/wp-content/uploads/2024/05/IMG_0698-1.jpg",
  },
  {
    id: 4,
    title: "Panadería Comercial Downtown",
    description: "Instalación comercial especializada con superficies resistentes y cumplimiento de normativas sanitarias.",
    category: "Proyecto Comercial",
    location: "Downtown Miami, FL",
    year: "2024",
    image: "https://ajp-services.com/wp-content/uploads/2024/05/bakery-2-of-26-scaled-1.jpg",
  },


  {
    id: 7,
    title: "Tienda Comercial Premium",
    description: "Proyecto comercial con diseño elegante y materiales de alta resistencia.",
    category: "Tienda Comercial",
    location: "Brickell, Miami FL",
    year: "2024",
    image: "https://ajp-services.com/wp-content/uploads/2024/05/E9559494-1009-4758-B739-8D259A672BA9-scaled-1.jpeg",
  },
  {
    id: 8,
    title: "Cocina Moderna con Isla",
    description: "Cocina contemporánea con isla central de cuarzo y diseño funcional.",
    category: "Cocina Moderna",
    location: "Doral, Miami FL",
    year: "2024",
    image: "https://ajp-services.com/wp-content/uploads/2024/05/51732B00-795A-4715-BEBE-800F9101C968-scaled-1.jpeg",
  },
  {
    id: 9,
    title: "Baño Spa Residencial",
    description: "Baño de lujo con diseño spa, mármol natural y acabados premium.",
    category: "Baño Spa",
    location: "Miami Beach, FL",
    year: "2024",
    image: "https://ajp-services.com/wp-content/uploads/2024/05/2219FB36-47F2-4BB6-8785-B6965877B6F9-scaled-1.jpeg",
  },
  {
    id: 10,
    title: "Encimera Vertical Premium",
    description: "Instalación de encimera vertical con mármol de alta calidad y acabados artesanales.",
    category: "Instalación Especial",
    location: "Coconut Grove, FL",
    year: "2024",
    image: "https://ajp-services.com/wp-content/uploads/2024/05/0756C730-8E40-46A5-BFA2-B644B4C5C2A7-scaled-1.jpeg",
  },
  {
    id: 11,
    title: "Proyecto Comercial Elegante",
    description: "Diseño comercial sofisticado con granito premium y acabados de lujo.",
    category: "Comercial Premium",
    location: "Coral Gables, FL",
    year: "2024",
    image: "https://ajp-services.com/wp-content/uploads/2024/05/697C20D0-26F6-477A-9AD9-11233FE92C67-scaled-1.jpeg",
  },

];

const getCategoriesForLanguage = (language: string) => {
  if (language === 'en') {
    return ["All", "Residential Kitchen", "Luxury Bathroom", "Commercial Project", "Integral Project"];
  } else if (language === 'pt') {
    return ["Todos", "Cozinha Residencial", "Banheiro de Luxo", "Projeto Comercial", "Projeto Integral"];
  } else {
    return ["Todos", "Cocina Residencial", "Baño de Lujo", "Proyecto Comercial", "Proyecto Integral"];
  }
};

export default function AllProjects() {
  const { t, language } = useLanguage();
  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="container mx-auto px-4 py-8">
        {/* Header with Back Button and Language Selector */}
        <div className="flex justify-between items-center mb-8">
          <Button 
            variant="outline" 
            onClick={() => window.history.back()}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            {language === 'en' ? 'Back to Home' : 
             language === 'pt' ? 'Voltar ao Início' : 
             'Volver al Inicio'}
          </Button>
          <LanguageSelector />
        </div>

        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold text-ajp-dark mb-4">
            {language === 'en' ? 'All Our Projects' :
             language === 'pt' ? 'Todos os Nossos Projetos' :
             'Todos Nuestros Proyectos'}
          </h1>
          <p className="text-xl text-ajp-gray max-w-3xl mx-auto">
            {language === 'en' ? 'Explore our extensive gallery of completed projects in Miami. Each work reflects our commitment to excellence and attention to detail.' :
             language === 'pt' ? 'Explore nossa extensa galeria de projetos concluídos em Miami. Cada trabalho reflete nosso compromisso com a excelência e atenção aos detalhes.' :
             'Explora nuestra amplia galería de proyectos completados en Miami. Cada trabajo refleja nuestro compromiso con la excelencia y la atención al detalle.'}
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {getCategoriesForLanguage(language).map((category) => (
            <button
              key={category}
              className="px-6 py-2 rounded-full border-2 border-ajp-gold text-ajp-gold hover:bg-ajp-gold hover:text-white transition-colors font-medium"
            >
              {category}
            </button>
          ))}
        </div>

        {/* Recommendations Section */}
        <ProjectRecommendations 
          allProjects={allProjects}
          title={language === 'en' ? 'Projects You Might Like' :
                 language === 'pt' ? 'Projetos que Você Pode Gostar' :
                 'Proyectos que Te Pueden Gustar'}
        />

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 mb-16">
          {allProjects.map((project) => (
            <Link key={project.id} href={`/proyecto/${project.id}`}>
              <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 group cursor-pointer">
                <div
                  className="aspect-video bg-cover bg-center group-hover:scale-105 transition-transform duration-300"
                  style={{ backgroundImage: `url('${project.image}')` }}
                />
                <div className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium bg-ajp-gold/10 text-ajp-gold px-2 py-1 rounded-full">
                      {project.category}
                    </span>
                    <span className="text-xs text-ajp-gray">{project.year}</span>
                  </div>
                  
                  <h3 className="text-lg font-semibold text-ajp-dark mb-2 line-clamp-2">
                    {t(`project.${project.id}.title`)}
                  </h3>
                  
                  <p className="text-ajp-gray text-sm mb-3 line-clamp-2">
                    {t(`project.${project.id}.desc`)}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-ajp-gray">
                      📍 {project.location}
                    </span>
                    <div className="flex items-center text-ajp-gold text-sm font-medium group-hover:text-yellow-600 transition-colors">
                      <ArrowRight className="w-4 h-4 mr-1" />
                      {language === 'en' ? 'View Details' :
                       language === 'pt' ? 'Ver Detalhes' :
                       'Ver Detalles'}
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Stats Section */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-16">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-ajp-gold mb-2">500+</div>
              <div className="text-ajp-gray">
                {language === 'en' ? 'Completed Projects' :
                 language === 'pt' ? 'Projetos Concluídos' :
                 'Proyectos Completados'}
              </div>
            </div>
            <div>
              <div className="text-3xl font-bold text-ajp-gold mb-2">15+</div>
              <div className="text-ajp-gray">
                {language === 'en' ? 'Years of Experience' :
                 language === 'pt' ? 'Anos de Experiência' :
                 'Años de Experiencia'}
              </div>
            </div>
            <div>
              <div className="text-3xl font-bold text-ajp-gold mb-2">100%</div>
              <div className="text-ajp-gray">
                {language === 'en' ? 'Satisfied Clients' :
                 language === 'pt' ? 'Clientes Satisfeitos' :
                 'Clientes Satisfechos'}
              </div>
            </div>
            <div>
              <div className="text-3xl font-bold text-ajp-gold mb-2">24/7</div>
              <div className="text-ajp-gray">
                {language === 'en' ? 'Technical Support' :
                 language === 'pt' ? 'Suporte Técnico' :
                 'Soporte Técnico'}
              </div>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-ajp-gold rounded-xl p-8 text-center text-white">
          <h2 className="text-3xl font-bold mb-4">
            {language === 'en' ? 'Ready for Your Next Project?' :
             language === 'pt' ? 'Pronto para seu Próximo Projeto?' :
             '¿Listo para tu Próximo Proyecto?'}
          </h2>
          <p className="text-xl mb-6 text-white/90">
            {language === 'en' ? 'Join hundreds of satisfied clients who have transformed their spaces with AJP Services' :
             language === 'pt' ? 'Junte-se a centenas de clientes satisfeitos que transformaram seus espaços com a AJP Services' :
             'Únete a cientos de clientes satisfechos que han transformado sus espacios con AJP Services'}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              className="bg-white text-[#1a284a] hover:bg-gray-100 font-semibold px-8 py-4"
              onClick={() => {
                window.location.href = '/#contacto';
              }}
            >
              {language === 'en' ? 'Request Quote' :
               language === 'pt' ? 'Solicitar Orçamento' :
               'Solicitar Cotización'}
            </Button>
            <Button 
              variant="outline"
              className="border-white text-[#001842] hover:bg-white hover:text-ajp-gold font-semibold px-8 py-4"
              onClick={() => window.open(`https://wa.me/13059757657?text=${encodeURIComponent(
                language === 'en' ? 'Hello, I am interested in getting a quote for an AJP Services project' :
                language === 'pt' ? 'Olá, tenho interesse em obter um orçamento para um projeto da AJP Services' :
                'Hola, me interesa obtener una cotización para un proyecto de AJP Services'
              )}`, '_blank')}
            >
              {language === 'en' ? 'Contact via WhatsApp' :
               language === 'pt' ? 'Contatar via WhatsApp' :
               'Contactar por WhatsApp'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}