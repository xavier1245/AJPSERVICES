import { useParams } from "wouter";
import { ArrowLeft, Calendar, MapPin, Tag, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { useState, useEffect } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import LanguageSelector from "@/components/LanguageSelector";
import { useProjectRecommendations } from "@/hooks/useProjectRecommendations";
import ProjectRecommendations from "@/components/ProjectRecommendations";

const projectsData = {


  3: {
    title: "Remodelación Casa Completa",
    location: "Key Biscayne, Miami FL",
    date: "2024",
    category: "Proyecto Integral",
    description: "Proyecto integral de remodelación incluyendo múltiples espacios con diferentes tipos de piedra natural, creando armonía y elegancia en toda la residencia.",
    images: [
      "https://ajp-services.com/wp-content/uploads/2024/05/IMG_0698-1.jpg",
      "https://ajp-services.com/wp-content/uploads/2024/05/IMG_0697-1.jpg",
      "https://ajp-services.com/wp-content/uploads/2024/05/IMG_0696-1.jpg"
    ],
    materials: [
      "Granito brasileño",
      "Cuarzo de ingeniería",
      "Mármol italiano",
      "Porcelanato gran formato"
    ],
    features: [
      "Coordinación de múltiples espacios",
      "Materiales complementarios",
      "Diseño cohesivo integral",
      "Acabados personalizados",
      "Proyecto llave en mano"
    ]
  },
  4: {
    title: "Panadería Comercial",
    location: "Downtown Miami, FL",
    date: "2024",
    category: "Proyecto Comercial",
    description: "Instalación comercial especializada para panadería con superficies resistentes a altas temperaturas, fácil limpieza y cumplimiento de normativas sanitarias.",
    images: [
      "https://ajp-services.com/wp-content/uploads/2024/05/bakery-2-of-26-scaled-1.jpg"
    ],
    materials: [
      "Cuarzo antibacterial",
      "Superficies sin juntas",
      "Acabados mate antideslizantes",
      "Bordes redondeados"
    ],
    features: [
      "Resistencia a altas temperaturas",
      "Fácil limpieza y desinfección",
      "Cumple normativas sanitarias",
      "Durabilidad comercial",
      "Diseño funcional para producción"
    ]
  },


  7: {
    title: "Tienda Comercial Premium",
    location: "Brickell, Miami FL",
    date: "2024",
    category: "Tienda Comercial",
    description: "Proyecto comercial con diseño elegante y materiales de alta resistencia para ambiente comercial de lujo.",
    images: [
      "https://ajp-services.com/wp-content/uploads/2024/05/E9559494-1009-4758-B739-8D259A672BA9-scaled-1.jpeg"
    ],
    materials: [
      "Granito comercial de alta resistencia",
      "Acabados anti-manchas",
      "Bordes reforzados",
      "Sellado industrial"
    ],
    features: [
      "Resistencia al tráfico pesado",
      "Mantenimiento mínimo",
      "Diseño comercial elegante",
      "Cumple estándares comerciales",
      "Garantía extendida comercial"
    ]
  },
  8: {
    title: "Cocina Moderna con Isla",
    location: "Doral, Miami FL",
    date: "2024",
    category: "Cocina Moderna",
    description: "Cocina contemporánea con isla central de cuarzo y diseño funcional optimizado para cocina moderna.",
    images: [
      "https://ajp-services.com/wp-content/uploads/2024/05/51732B00-795A-4715-BEBE-800F9101C968-scaled-1.jpeg"
    ],
    materials: [
      "Cuarzo de ingeniería",
      "Isla multifuncional",
      "Acabados modernos",
      "Hardware premium"
    ],
    features: [
      "Diseño minimalista",
      "Funcionalidad optimizada",
      "Fácil mantenimiento",
      "Estilo contemporáneo",
      "Durabilidad garantizada"
    ]
  },
  9: {
    title: "Baño Spa Residencial",
    location: "Miami Beach, FL",
    date: "2024",
    category: "Baño Spa",
    description: "Baño de lujo con diseño spa, mármol natural y acabados premium para una experiencia de relajación total.",
    images: [
      "https://ajp-services.com/wp-content/uploads/2024/05/2219FB36-47F2-4BB6-8785-B6965877B6F9-scaled-1.jpeg"
    ],
    materials: [
      "Mármol natural premium",
      "Acabados spa de lujo",
      "Grifería de diseño",
      "Iluminación ambiental"
    ],
    features: [
      "Ambiente de spa profesional",
      "Materiales de lujo",
      "Diseño relajante",
      "Acabados premium",
      "Experiencia de spa en casa"
    ]
  },
  10: {
    title: "Encimera Vertical Premium",
    location: "Coconut Grove, FL",
    date: "2024",
    category: "Instalación Especial",
    description: "Instalación de encimera vertical con mármol de alta calidad y acabados artesanales especializados.",
    images: [
      "https://ajp-services.com/wp-content/uploads/2024/05/0756C730-8E40-46A5-BFA2-B644B4C5C2A7-scaled-1.jpeg"
    ],
    materials: [
      "Mármol seleccionado",
      "Instalación vertical especializada",
      "Acabados artesanales",
      "Soporte estructural"
    ],
    features: [
      "Técnica de instalación única",
      "Trabajo artesanal especializado",
      "Diseño vertical innovador",
      "Acabados de precisión",
      "Instalación técnica avanzada"
    ]
  },
  11: {
    title: "Proyecto Comercial Elegante",
    location: "Coral Gables, FL",
    date: "2024",
    category: "Comercial Premium",
    description: "Diseño comercial sofisticado con granito premium y acabados de lujo para ambiente comercial de alta gama.",
    images: [
      "https://ajp-services.com/wp-content/uploads/2024/05/697C20D0-26F6-477A-9AD9-11233FE92C67-scaled-1.jpeg"
    ],
    materials: [
      "Granito premium importado",
      "Acabados comerciales de lujo",
      "Instalación profesional",
      "Herrajes comerciales"
    ],
    features: [
      "Estándar comercial premium",
      "Diseño sofisticado",
      "Durabilidad comercial",
      "Acabados de lujo",
      "Instalación profesional certificada"
    ]
  },


};

export default function ProjectDetail() {
  const params = useParams();
  const projectId = parseInt(params.id || "1");
  const project = projectsData[projectId as keyof typeof projectsData];
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const { language, t } = useLanguage();
  const { trackProjectView } = useProjectRecommendations();

  // Track project view when component mounts
  useEffect(() => {
    if (project) {
      trackProjectView({
        id: projectId,
        title: project.title,
        category: project.category,
        location: project.location,
        year: project.date,
        image: project.images[0],
        description: project.description
      });
    }
  }, [projectId]); // Only depend on projectId to avoid infinite loops

  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-ajp-dark mb-4">Proyecto no encontrado</h1>
          <Button onClick={() => window.history.back()}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="container mx-auto px-4 py-8">
        {/* Header with Back Button and Language Selector */}
        <div className="flex justify-between items-center mb-8">
          <Button 
            variant="outline" 
            onClick={() => window.location.href = '/'}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            {language === 'en' ? 'Back to Home' :
             language === 'pt' ? 'Voltar ao Início' :
             'Volver al Inicio'}
          </Button>
          <LanguageSelector />
        </div>

        {/* Project Header */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-8">
          <div 
            className="h-96 bg-cover bg-center relative"
            style={{ backgroundImage: `url('${project.images[0]}')` }}
          >
            <div className="absolute inset-0 bg-black/40" />
            <div className="absolute bottom-8 left-8 text-white">
              <h1 className="text-4xl font-bold mb-2">{t(`project.${projectId}.title`)}</h1>
              <div className="flex items-center space-x-4">
                <div className="flex items-center">
                  <MapPin className="w-5 h-5 mr-2" />
                  {project.location}
                </div>
                <div className="flex items-center">
                  <Calendar className="w-5 h-5 mr-2" />
                  {project.date}
                </div>
                <div className="flex items-center">
                  <Tag className="w-5 h-5 mr-2" />
                  {project.category}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Description */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-ajp-dark mb-4">
                {language === 'en' ? 'Project Description' :
                 language === 'pt' ? 'Descrição do Projeto' :
                 'Descripción del Proyecto'}
              </h2>
              <p className="text-ajp-gray text-lg leading-relaxed">
                {t(`project.${projectId}.desc`)}
              </p>
            </div>

            {/* Image Gallery */}
            {project.images.length > 1 && (
              <div className="bg-white rounded-xl shadow-lg p-8">
                <h2 className="text-2xl font-bold text-ajp-dark mb-6">
                  {language === 'en' ? 'Image Gallery' :
                   language === 'pt' ? 'Galeria de Imagens' :
                   'Galería de Imágenes'}
                </h2>
                <div className="grid md:grid-cols-2 gap-6">
                  {project.images.slice(1).map((image, index) => (
                    <div 
                      key={index}
                      className="aspect-video bg-cover bg-center rounded-lg shadow-md hover:shadow-lg transition-all cursor-pointer group"
                      style={{ backgroundImage: `url('${image}')` }}
                      onClick={() => setSelectedImage(image)}
                    >
                      <div className="w-full h-full bg-black/0 group-hover:bg-black/20 transition-colors rounded-lg flex items-center justify-center">
                        <span className="text-white opacity-0 group-hover:opacity-100 transition-opacity font-semibold">
                          {language === 'en' ? 'Click to expand' :
                           language === 'pt' ? 'Clique para expandir' :
                           'Click para expandir'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Image Modal */}
            {selectedImage && (
              <div 
                className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
                onClick={() => setSelectedImage(null)}
              >
                <div className="relative max-w-4xl max-h-full">
                  <button
                    onClick={() => setSelectedImage(null)}
                    className="absolute top-4 right-4 z-10 bg-white/20 hover:bg-white/30 text-white rounded-full p-2 transition-colors"
                  >
                    <X className="w-6 h-6" />
                  </button>
                  <img 
                    src={selectedImage} 
                    alt="Imagen expandida" 
                    className="max-w-full max-h-full object-contain rounded-lg"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Materials */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-bold text-ajp-dark mb-4">
                {language === 'en' ? 'Materials Used' :
                 language === 'pt' ? 'Materiais Utilizados' :
                 'Materiales Utilizados'}
              </h3>
              <ul className="space-y-3">
                {project.materials.map((material, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="w-5 h-5 text-ajp-gold mr-3 flex-shrink-0 mt-0.5" />
                    <span className="text-ajp-gray">{material}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Features */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-bold text-ajp-dark mb-4">
                {language === 'en' ? 'Featured Characteristics' :
                 language === 'pt' ? 'Características Destacadas' :
                 'Características Destacadas'}
              </h3>
              <ul className="space-y-3">
                {project.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="w-5 h-5 text-ajp-gold mr-3 flex-shrink-0 mt-0.5" />
                    <span className="text-ajp-gray">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* CTA */}
            <div className="bg-ajp-gold rounded-xl p-6 text-center">
              <h3 className="text-xl font-bold text-white mb-3">
                {language === 'en' ? 'Did you like this project?' :
                 language === 'pt' ? 'Gostou deste projeto?' :
                 '¿Te gustó este proyecto?'}
              </h3>
              <p className="text-white/90 mb-4">
                {language === 'en' ? 'Contact us via WhatsApp for a personalized quote' :
                 language === 'pt' ? 'Entre em contato conosco via WhatsApp para um orçamento personalizado' :
                 'Contáctanos por WhatsApp para una cotización personalizada'}
              </p>
              <Button 
                className="bg-white text-ajp-gold hover:bg-gray-100 font-semibold"
                onClick={() => window.open(`https://wa.me/13059757657?text=${encodeURIComponent(
                  language === 'en' ? `Hello, I liked the project "${project.title}" and I'm interested in getting a similar quote for my space.` :
                  language === 'pt' ? `Olá, gostei do projeto "${project.title}" e tenho interesse em obter um orçamento similar para meu espaço.` :
                  `Hola, me gustó el proyecto "${project.title}" y me interesa obtener una cotización similar para mi espacio.`
                )}`, '_blank')}
              >
                {language === 'en' ? 'Contact via WhatsApp' :
                 language === 'pt' ? 'Contatar via WhatsApp' :
                 'Contactar por WhatsApp'}
              </Button>
            </div>
          </div>
        </div>

        {/* Project Recommendations */}
        <ProjectRecommendations 
          allProjects={Object.entries(projectsData).map(([key, p]) => ({
            id: parseInt(key),
            title: p.title,
            category: p.category,
            location: p.location,
            year: p.date,
            image: p.images[0],
            description: p.description
          }))}
          currentProjectId={projectId}
        />
      </div>
    </div>
  );
}