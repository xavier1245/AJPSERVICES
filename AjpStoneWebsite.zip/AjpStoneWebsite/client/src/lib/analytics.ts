// Define the gtag function globally
declare global {
  interface Window {
    dataLayer: any[];
    gtag: (...args: any[]) => void;
    fbq: (...args: any[]) => void;
  }
}

// Initialize Google Analytics
export const initGA = () => {
  const measurementId = import.meta.env.VITE_GA_MEASUREMENT_ID;

  if (!measurementId) {
    console.warn('Missing required Google Analytics key: VITE_GA_MEASUREMENT_ID');
    return;
  }

  // Add Google Analytics script to the head
  const script1 = document.createElement('script');
  script1.async = true;
  script1.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`;
  document.head.appendChild(script1);

  // Initialize gtag
  const script2 = document.createElement('script');
  script2.textContent = `
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '${measurementId.replace(/['"\\]/g, '')}', {
      page_title: 'AJP Stone & Services',
      page_location: window.location.href,
      custom_map: {
        'custom_parameter_1': 'construction_company'
      }
    });
  `;
  document.head.appendChild(script2);
};

// Initialize Facebook Pixel
export const initFacebookPixel = () => {
  const pixelId = import.meta.env.VITE_FACEBOOK_PIXEL_ID;
  
  if (!pixelId) {
    console.warn('Missing Facebook Pixel ID: VITE_FACEBOOK_PIXEL_ID');
    return;
  }

  const script = document.createElement('script');
  script.textContent = `
    !function(f,b,e,v,n,t,s)
    {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window, document,'script',
    'https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '${pixelId.replace(/['"\\]/g, '')}');
    fbq('track', 'PageView');
  `;
  document.head.appendChild(script);
};

// Track page views - useful for single-page applications
export const trackPageView = (url: string) => {
  if (typeof window === 'undefined') return;
  
  // Google Analytics
  if (window.gtag) {
    const measurementId = import.meta.env.VITE_GA_MEASUREMENT_ID;
    if (measurementId) {
      window.gtag('config', measurementId, {
        page_path: url,
        page_title: document.title
      });
    }
  }

  // Facebook Pixel
  if (window.fbq) {
    window.fbq('track', 'PageView');
  }
};

// Track events
export const trackEvent = (
  action: string, 
  category?: string, 
  label?: string, 
  value?: number
) => {
  if (typeof window === 'undefined') return;
  
  // Google Analytics
  if (window.gtag) {
    window.gtag('event', action, {
      event_category: category,
      event_label: label,
      value: value,
    });
  }

  // Facebook Pixel custom events
  if (window.fbq) {
    window.fbq('trackCustom', action, {
      category: category,
      label: label,
      value: value
    });
  }
};

// Track specific business events
export const trackBusinessEvent = (event: string, data?: any) => {
  if (typeof window === 'undefined') return;

  const businessEvents = {
    contact_form_submit: () => {
      trackEvent('form_submit', 'contact', 'contact_form');
      if (window.fbq) window.fbq('track', 'Contact');
    },
    quote_request: () => {
      trackEvent('generate_lead', 'quote', 'quote_request');
      if (window.fbq) window.fbq('track', 'Lead');
    },
    whatsapp_click: () => {
      trackEvent('click', 'communication', 'whatsapp_contact');
      if (window.fbq) window.fbq('track', 'Contact');
    },
    project_view: (projectId: string) => {
      trackEvent('view_item', 'project', `project_${projectId}`);
      if (window.fbq) window.fbq('track', 'ViewContent', { content_name: `Project ${projectId}` });
    },
    language_change: (language: string) => {
      trackEvent('language_change', 'user_preference', language);
    }
  };

  const eventFunction = businessEvents[event as keyof typeof businessEvents];
  if (eventFunction) {
    if (data) {
      eventFunction(data);
    } else {
      eventFunction();
    }
  }
};