import { ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { useLanguage } from "../contexts/LanguageContext";
import { FadeInSection } from "./FadeInSection";
import { OptimizedImage } from "./OptimizedImage";

const projects = [


  {
    id: 3,
    title: "Remodelación Casa Completa",
    description:
      "Proyecto integral con múltiples superficies de piedra natural.",
    image:
      "https://ajp-services.com/wp-content/uploads/2024/05/IMG_0698-1.jpg",
  },
  {
    id: 4,
    title: "Panadería Comercial Downtown",
    description:
      "Instalación comercial con superficies resistentes y diseño funcional.",
    image:
      "https://ajp-services.com/wp-content/uploads/2024/05/bakery-2-of-26-scaled-1.jpg",
  },
];

export default function Projects() {
  const { t } = useLanguage();
  return (
    <section id="proyectos" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <FadeInSection>
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-ajp-dark mb-4">
              {t('projects.title')}
            </h2>
            <p className="text-xl text-ajp-gray max-w-3xl mx-auto">
              {t('projects.subtitle')}
            </p>
          </div>
        </FadeInSection>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <FadeInSection key={project.id} delay={index * 150}>
              <Link href={`/proyecto/${project.id}`}>
                <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow group cursor-pointer">
                  <OptimizedImage
                    src={project.image}
                    alt={`Project ${project.id} - ${project.category}`}
                    className="aspect-video object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="p-6">
                    <h3 className="text-xl font-semibold text-ajp-dark mb-2">
                      {t(`project.${project.id}.title`)}
                    </h3>
                    <p className="text-ajp-gray mb-4">{t(`project.${project.id}.desc`)}</p>
                    <div className="flex items-center text-ajp-gold text-sm font-medium group-hover:text-yellow-600 transition-colors">
                      <ArrowRight className="w-4 h-4 mr-2" />
                      {t('projects.viewDetails')}
                    </div>
                  </div>
                </div>
              </Link>
            </FadeInSection>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/proyectos">
            <button className="bg-ajp-gold hover:bg-yellow-600 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors shadow-lg">
              {t('projects.viewAll')}
            </button>
          </Link>
        </div>
      </div>
    </section>
  );
}
