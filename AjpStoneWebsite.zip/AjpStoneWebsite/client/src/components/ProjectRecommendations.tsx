import { useProjectRecommendations } from "@/hooks/useProjectRecommendations";
import { useLanguage } from "@/contexts/LanguageContext";
import { ArrowRight, Star } from "lucide-react";
import { Link } from "wouter";

interface Project {
  id: number;
  title: string;
  category: string;
  location: string;
  year: string;
  image: string;
  description: string;
}

interface ProjectRecommendationsProps {
  allProjects: Project[];
  currentProjectId?: number;
  title?: string;
}

export default function ProjectRecommendations({ 
  allProjects, 
  currentProjectId, 
  title 
}: ProjectRecommendationsProps) {
  const { getRecommendations } = useProjectRecommendations();
  const { t, language } = useLanguage();

  const defaultTitle = language === 'en' ? 'Recommended Projects' :
                      language === 'pt' ? 'Projetos Recomendados' :
                      'Proyectos Recomendados';

  const recommendations = getRecommendations(allProjects, currentProjectId, 4);

  if (recommendations.length === 0) {
    return (
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center mb-8">
            <Star className="w-6 h-6 text-ajp-gold mr-3" />
            <h2 className="text-3xl font-bold text-ajp-dark">
              {defaultTitle}
            </h2>
          </div>
          <p className="text-ajp-gray">
            {language === 'en' ? 'Explore more projects to get personalized recommendations' :
             language === 'pt' ? 'Explore mais projetos para obter recomendações personalizadas' :
             'Explora más proyectos para obtener recomendaciones personalizadas'}
          </p>
        </div>
      </section>
    );
  }

  return (
    <section className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-center mb-8">
          <Star className="w-6 h-6 text-ajp-gold mr-3" />
          <h2 className="text-3xl font-bold text-ajp-dark">
            {title || defaultTitle}
          </h2>
        </div>
        
        <p className="text-center text-ajp-gray mb-12 max-w-2xl mx-auto">
          {language === 'en' ? 'Based on your viewing preferences, we think you might like these projects' :
           language === 'pt' ? 'Com base em suas preferências de visualização, achamos que você pode gostar destes projetos' :
           'Basado en tus preferencias de visualización, creemos que te pueden gustar estos proyectos'}
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {recommendations.map((project) => (
            <Link key={project.id} href={`/proyecto/${project.id}`}>
              <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 group cursor-pointer">
                <div className="relative">
                  <div
                    className="aspect-video bg-cover bg-center group-hover:scale-105 transition-transform duration-300"
                    style={{ backgroundImage: `url('${project.image}')` }}
                  />
                  <div className="absolute top-3 right-3">
                    <div className="bg-ajp-gold/90 backdrop-blur-sm text-white px-2 py-1 rounded-full text-xs font-medium">
                      {language === 'en' ? 'Recommended' :
                       language === 'pt' ? 'Recomendado' :
                       'Recomendado'}
                    </div>
                  </div>
                </div>
                
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-ajp-dark mb-2 line-clamp-2">
                    {t(`project.${project.id}.title`)}
                  </h3>
                  
                  <p className="text-ajp-gray text-sm mb-3 line-clamp-2">
                    {t(`project.${project.id}.desc`)}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-ajp-gray">
                      📍 {project.location.split(',')[0]}
                    </span>
                    <div className="flex items-center text-ajp-gold text-sm font-medium group-hover:text-yellow-600 transition-colors">
                      <ArrowRight className="w-4 h-4 mr-1" />
                      {language === 'en' ? 'View' :
                       language === 'pt' ? 'Ver' :
                       'Ver'}
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}