import { Gem, Diamond, Mountain, Layers } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";
import { FadeInSection } from "./FadeInSection";

const servicesData = [
  {
    icon: Gem,
    titleKey: "services.marble.title",
    descriptionKey: "services.marble.desc",
    features: [
      "Carrara, Calacatta, Statuario",
      "Encimeras y backsplashes",
      "Pisos y revestimientos",
    ],
  },
  {
    icon: Diamond,
    titleKey: "services.quartz.title",
    descriptionKey: "services.quartz.desc",
    features: [
      "Caesarstone, Silestone",
      "Resistente a manchas",
      "Mantenimiento mínimo",
    ],
  },
  {
    icon: Mountain,
    titleKey: "services.granite.title",
    descriptionKey: "services.granite.desc",
    features: [
      "Variedad de colores",
      "Resistencia al calor",
      "Acabados personalizados",
    ],
  },
  {
    icon: Layers,
    titleKey: "services.porcelain.title",
    descriptionKey: "services.porcelain.desc",
    features: [
      "Gran formato",
      "Imitación perfecta",
      "Fácil mantenimiento",
    ],
  },
];

export default function Services() {
  const { t } = useLanguage();
  return (
    <section id="servicios" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <FadeInSection>
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-ajp-dark mb-4">
              {t('services.title')}
            </h2>
            <p className="text-xl text-ajp-gray max-w-3xl mx-auto">
              {t('services.subtitle')}
            </p>
          </div>
        </FadeInSection>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {servicesData.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <FadeInSection key={index} delay={index * 200}>
                <div className="bg-gray-50 p-8 rounded-xl hover:shadow-xl transition-shadow group">
                  <div className="w-16 h-16 bg-ajp-gold/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-ajp-gold/20 transition-colors">
                    <IconComponent className="w-8 h-8 text-ajp-gold icon-spin-slow group-hover:icon-spin-fast" />
                  </div>
                  <h3 className="text-2xl font-semibold text-ajp-dark mb-4">
                    {t(service.titleKey)}
                  </h3>
                  <p className="text-ajp-gray mb-4">{t(service.descriptionKey)}</p>
                  <ul className="text-sm text-ajp-gray space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex}>• {feature}</li>
                    ))}
                  </ul>
                </div>
              </FadeInSection>
            );
          })}
        </div>
      </div>
    </section>
  );
}
