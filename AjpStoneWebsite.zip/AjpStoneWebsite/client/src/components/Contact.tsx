import { useState } from "react";
import { MapPin, Phone, Mail, Clock, Check, MessageCircle } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

export default function Contact() {
  const { t } = useLanguage();
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    projectType: "",
    message: "",
  });
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Error",
        description: "Por favor complete todos los campos requeridos.",
        variant: "destructive",
      });
      return;
    }

    // Simulate form submission
    toast({
      title: "Solicitud Enviada",
      description: "Hemos recibido su solicitud. Nos pondremos en contacto pronto.",
    });

    // Reset form
    setFormData({
      name: "",
      phone: "",
      email: "",
      projectType: "",
      message: "",
    });
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: t('contact.address.title'),
      content: "1234 Brickell Avenue\nMiami, FL 33131",
    },
    {
      icon: Phone,
      title: t('contact.phone.title'),
      content: "(305) 975-7657",
    },
    {
      icon: Mail,
      title: t('contact.email.title'),
      content: "info@ajpstone.com",
    },
    {
      icon: Clock,
      title: t('contact.hours.title'),
      content: t('contact.hours.content'),
    },
  ];

  const benefits = [
    t('contact.benefit.1'),
    t('contact.benefit.2'),
    t('contact.benefit.3'),
    t('contact.benefit.4'),
  ];

  return (
    <section id="contacto" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-ajp-dark mb-4">
            {t('contact.title')}
          </h2>
          <p className="text-xl text-ajp-gray max-w-3xl mx-auto">
            {t('contact.subtitle')}
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="bg-gray-50 p-8 rounded-xl">
            <h3 className="text-2xl font-semibold text-ajp-dark mb-6">
              {t('contact.form.title')}
            </h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-ajp-dark font-medium mb-2">
                    {t('contact.form.name')} *
                  </label>
                  <Input
                    type="text"
                    placeholder="Tu nombre completo"
                    value={formData.name}
                    onChange={(e) => handleInputChange("name", e.target.value)}
                    className="focus:border-ajp-gold focus:ring-ajp-gold/20"
                  />
                </div>
                <div>
                  <label className="block text-ajp-dark font-medium mb-2">
                    {t('contact.form.phone')}
                  </label>
                  <Input
                    type="tel"
                    placeholder="(305) 975-7657"
                    value={formData.phone}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    className="focus:border-ajp-gold focus:ring-ajp-gold/20"
                  />
                </div>
              </div>

              <div>
                <label className="block text-ajp-dark font-medium mb-2">
                  {t('contact.form.email')} *
                </label>
                <Input
                  type="email"
                  placeholder="tu@email.com"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  className="focus:border-ajp-gold focus:ring-ajp-gold/20"
                />
              </div>

              <div>
                <label className="block text-ajp-dark font-medium mb-2">
                  {t('contact.form.projectType')}
                </label>
                <Select value={formData.projectType} onValueChange={(value) => handleInputChange("projectType", value)}>
                  <SelectTrigger className="focus:border-ajp-gold focus:ring-ajp-gold/20">
                    <SelectValue placeholder="Selecciona el tipo de proyecto" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cocina">Cocina Residencial</SelectItem>
                    <SelectItem value="bano">Baño Principal</SelectItem>
                    <SelectItem value="pisos">Pisos y Revestimientos</SelectItem>
                    <SelectItem value="comercial">Proyecto Comercial</SelectItem>
                    <SelectItem value="chimenea">Chimenea</SelectItem>
                    <SelectItem value="otro">Otro</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-ajp-dark font-medium mb-2">
                  {t('contact.form.message')} *
                </label>
                <Textarea
                  rows={4}
                  placeholder="Describe tu proyecto..."
                  value={formData.message}
                  onChange={(e) => handleInputChange("message", e.target.value)}
                  className="focus:border-ajp-gold focus:ring-ajp-gold/20"
                />
              </div>

              <div className="space-y-3">
                <Button
                  type="submit"
                  className="w-full bg-ajp-gold hover:bg-yellow-600 text-white py-4 text-lg font-semibold shadow-lg"
                >
                  {t('contact.form.submit')}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full border-green-500 text-green-600 hover:bg-green-50 py-4 text-lg font-semibold"
                  onClick={() => window.open('https://wa.me/13059757657?text=Hola%2C%20me%20interesa%20obtener%20una%20cotización%20para%20un%20proyecto%20de%20AJP%20Services', '_blank')}
                >
                  <MessageCircle className="w-5 h-5 mr-2" />
                  {t('contact.form.whatsapp')}
                </Button>
              </div>
            </form>
          </div>

          {/* Contact Information */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-semibold text-ajp-dark mb-6">
                {t('contact.info.title')}
              </h3>

              <div className="space-y-6">
                {contactInfo.map((info, index) => {
                  const IconComponent = info.icon;
                  return (
                    <div key={index} className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-ajp-gold/10 rounded-lg flex items-center justify-center flex-shrink-0">
                        <IconComponent className="w-6 h-6 text-ajp-gold" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-ajp-dark mb-1">
                          {info.title}
                        </h4>
                        <p className="text-ajp-gray whitespace-pre-line">
                          {info.content}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-gray-50 p-6 rounded-xl">
              <h4 className="font-semibold text-ajp-dark mb-3">
                {t('contact.why.title')}
              </h4>
              <ul className="space-y-2 text-ajp-gray">
                {benefits.map((benefit, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="w-5 h-5 text-ajp-gold mr-3 flex-shrink-0" />
                    {benefit}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
