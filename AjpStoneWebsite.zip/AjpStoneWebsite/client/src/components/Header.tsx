import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import LanguageSelector from "./LanguageSelector";
import { useLanguage } from "../contexts/LanguageContext";

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { t } = useLanguage();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerHeight = 80;
      const targetPosition = element.offsetTop - headerHeight;
      window.scrollTo({
        top: targetPosition,
        behavior: "smooth",
      });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-white shadow-lg" : "bg-white/95 backdrop-blur-sm shadow-lg"
      }`}
      style={{ cursor: 'auto' }}
    >
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-16 h-12 flex items-center justify-start">
              <img 
                src="http://ajp-services.com/wp-content/uploads/2021/08/ajpservices.png" 
                alt="AJP Services Logo" 
                className="h-8 w-auto object-contain"
              />
            </div>
            <div className="hidden md:block">
              <div className="text-ajp-dark font-semibold text-lg">
                AJP Stone & Services
              </div>
              <div className="text-ajp-gray text-sm">
                Construcción de Alta Gama
              </div>
            </div>
          </div>

          <div className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => scrollToSection("inicio")}
              className="text-ajp-dark hover:text-ajp-gold active:scale-95 active:bg-ajp-gold/10 transition-all duration-150 font-medium px-3 py-2 rounded-lg"
              data-interactive="true"
            >
              {t('nav.home')}
            </button>
            <button
              onClick={() => scrollToSection("servicios")}
              className="text-ajp-dark hover:text-ajp-gold active:scale-95 active:bg-ajp-gold/10 transition-all duration-150 font-medium px-3 py-2 rounded-lg"
              data-interactive="true"
            >
              {t('nav.services')}
            </button>
            <button
              onClick={() => scrollToSection("proyectos")}
              className="text-ajp-dark hover:text-ajp-gold active:scale-95 active:bg-ajp-gold/10 transition-all duration-150 font-medium px-3 py-2 rounded-lg"
              data-interactive="true"
            >
              {t('nav.projects')}
            </button>
            <button
              onClick={() => scrollToSection("proceso")}
              className="text-ajp-dark hover:text-ajp-gold active:scale-95 active:bg-ajp-gold/10 transition-all duration-150 font-medium px-3 py-2 rounded-lg"
              data-interactive="true"
            >
              {t('nav.process')}
            </button>
            <button
              onClick={() => scrollToSection("cita")}
              className="text-ajp-dark hover:text-ajp-gold active:scale-95 active:bg-ajp-gold/10 transition-all duration-150 font-medium px-3 py-2 rounded-lg"
              data-interactive="true"
            >
              {t('nav.appointment')}
            </button>
            <button
              onClick={() => scrollToSection("contacto")}
              className="text-ajp-dark hover:text-ajp-gold active:scale-95 active:bg-ajp-gold/10 transition-all duration-150 font-medium px-3 py-2 rounded-lg"
              data-interactive="true"
            >
              {t('nav.contact')}
            </button>
            <LanguageSelector />
          </div>

          <button
            className="md:hidden text-ajp-dark hover:text-ajp-gold active:scale-90 transition-all duration-150 p-2 rounded-lg"
            data-interactive="true"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-gray-200">
            <div className="flex flex-col space-y-4">
              <button
                onClick={() => scrollToSection("inicio")}
                className="text-ajp-dark hover:text-ajp-gold active:scale-95 active:bg-ajp-gold/10 transition-all duration-150 font-medium text-left w-full px-3 py-2 rounded-lg"
                data-interactive="true"
              >
                {t('nav.home')}
              </button>
              <button
                onClick={() => scrollToSection("servicios")}
                className="text-ajp-dark hover:text-ajp-gold active:scale-95 active:bg-ajp-gold/10 transition-all duration-150 font-medium text-left w-full px-3 py-2 rounded-lg"
                data-interactive="true"
              >
                {t('nav.services')}
              </button>
              <button
                onClick={() => scrollToSection("proyectos")}
                className="text-ajp-dark hover:text-ajp-gold active:scale-95 active:bg-ajp-gold/10 transition-all duration-150 font-medium text-left w-full px-3 py-2 rounded-lg"
                data-interactive="true"
              >
                {t('nav.projects')}
              </button>
              <button
                onClick={() => scrollToSection("proceso")}
                className="text-ajp-dark hover:text-ajp-gold active:scale-95 active:bg-ajp-gold/10 transition-all duration-150 font-medium text-left w-full px-3 py-2 rounded-lg"
                data-interactive="true"
              >
                {t('nav.process')}
              </button>
              <button
                onClick={() => scrollToSection("cita")}
                className="text-ajp-dark hover:text-ajp-gold active:scale-95 active:bg-ajp-gold/10 transition-all duration-150 font-medium text-left w-full px-3 py-2 rounded-lg"
                data-interactive="true"
              >
                {t('nav.appointment')}
              </button>
              <button
                onClick={() => scrollToSection("contacto")}
                className="text-ajp-dark hover:text-ajp-gold active:scale-95 active:bg-ajp-gold/10 transition-all duration-150 font-medium text-left w-full px-3 py-2 rounded-lg"
                data-interactive="true"
              >
                {t('nav.contact')}
              </button>
              <div className="pt-4 border-t border-gray-200">
                <LanguageSelector />
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
