import { ReactNode } from 'react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

interface FadeInSectionProps {
  children: ReactNode;
  className?: string;
  delay?: number;
  direction?: 'up' | 'down' | 'left' | 'right';
  distance?: number;
}

export function FadeInSection({ 
  children, 
  className = '', 
  delay = 0, 
  direction = 'up',
  distance = 20
}: FadeInSectionProps) {
  const { ref, isIntersecting } = useIntersectionObserver({ 
    threshold: 0.1,
    triggerOnce: true 
  });

  const getTransform = () => {
    if (isIntersecting) return 'translate3d(0, 0, 0)';
    
    switch (direction) {
      case 'up': return `translate3d(0, ${distance}px, 0)`;
      case 'down': return `translate3d(0, -${distance}px, 0)`;
      case 'left': return `translate3d(${distance}px, 0, 0)`;
      case 'right': return `translate3d(-${distance}px, 0, 0)`;
      default: return `translate3d(0, ${distance}px, 0)`;
    }
  };

  return (
    <div
      ref={ref}
      className={`transition-all duration-1000 ease-out will-change-transform ${className}`}
      style={{ 
        opacity: isIntersecting ? 1 : 0,
        transform: getTransform(),
        transitionDelay: `${delay}ms` 
      }}
    >
      {children}
    </div>
  );
}

export default FadeInSection;