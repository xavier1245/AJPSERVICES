import { useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Calendar, Clock, MapPin, Phone, Mail, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

export default function Appointment() {
  const { language, t } = useLanguage();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    serviceType: "",
    preferredDate: "",
    preferredTime: "",
    address: "",
    notes: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.phone) {
      toast({
        title: language === 'en' ? "Error" : language === 'pt' ? "Erro" : "Error",
        description: language === 'en' ? "Please fill in all required fields." :
                    language === 'pt' ? "Por favor, preencha todos os campos obrigatórios." :
                    "Por favor complete todos los campos requeridos.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: language === 'en' ? "Appointment Requested" :
             language === 'pt' ? "Consulta Solicitada" :
             "Cita Solicitada",
      description: language === 'en' ? "We have received your appointment request. We will contact you soon to confirm." :
                  language === 'pt' ? "Recebemos sua solicitação de consulta. Entraremos em contato em breve para confirmar." :
                  "Hemos recibido su solicitud de cita. Nos pondremos en contacto pronto para confirmar.",
    });

    setFormData({
      name: "",
      phone: "",
      email: "",
      serviceType: "",
      preferredDate: "",
      preferredTime: "",
      address: "",
      notes: "",
    });
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const serviceTypes = {
    es: [
      { value: "kitchen", label: "Cocina Residencial" },
      { value: "bathroom", label: "Baño Principal" },
      { value: "floors", label: "Pisos y Revestimientos" },
      { value: "commercial", label: "Proyecto Comercial" },
      { value: "fireplace", label: "Chimenea" },
      { value: "outdoor", label: "Cocina Exterior" },
      { value: "consultation", label: "Consulta General" },
    ],
    en: [
      { value: "kitchen", label: "Residential Kitchen" },
      { value: "bathroom", label: "Master Bathroom" },
      { value: "floors", label: "Floors & Coverings" },
      { value: "commercial", label: "Commercial Project" },
      { value: "fireplace", label: "Fireplace" },
      { value: "outdoor", label: "Outdoor Kitchen" },
      { value: "consultation", label: "General Consultation" },
    ],
    pt: [
      { value: "kitchen", label: "Cozinha Residencial" },
      { value: "bathroom", label: "Banheiro Principal" },
      { value: "floors", label: "Pisos e Revestimentos" },
      { value: "commercial", label: "Projeto Comercial" },
      { value: "fireplace", label: "Lareira" },
      { value: "outdoor", label: "Cozinha Externa" },
      { value: "consultation", label: "Consulta Geral" },
    ]
  };

  const timeSlots = [
    "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
    "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM"
  ];

  return (
    <section id="cita" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-ajp-dark mb-4">
            {t('appointment.title')}
          </h2>
          <p className="text-xl text-ajp-gray max-w-3xl mx-auto">
            {t('appointment.subtitle')}
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Appointment Form */}
          <div className="bg-white p-8 rounded-xl shadow-lg">
            <h3 className="text-2xl font-semibold text-ajp-dark mb-6">
              {language === 'en' ? 'Schedule Your Visit' :
               language === 'pt' ? 'Agende sua Visita' :
               'Programa tu Visita'}
            </h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-ajp-dark font-medium mb-2">
                    {t('contact.form.name')} *
                  </label>
                  <Input
                    type="text"
                    placeholder={language === 'en' ? 'Your full name' :
                               language === 'pt' ? 'Seu nome completo' :
                               'Tu nombre completo'}
                    value={formData.name}
                    onChange={(e) => handleInputChange("name", e.target.value)}
                    className="focus:border-ajp-gold focus:ring-ajp-gold/20"
                  />
                </div>
                <div>
                  <label className="block text-ajp-dark font-medium mb-2">
                    {t('contact.form.phone')} *
                  </label>
                  <Input
                    type="tel"
                    placeholder="(305) 975-7657"
                    value={formData.phone}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    className="focus:border-ajp-gold focus:ring-ajp-gold/20"
                  />
                </div>
              </div>

              <div>
                <label className="block text-ajp-dark font-medium mb-2">
                  {t('contact.form.email')} *
                </label>
                <Input
                  type="email"
                  placeholder={language === 'en' ? 'your@email.com' :
                             language === 'pt' ? 'seu@email.com' :
                             'tu@email.com'}
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  className="focus:border-ajp-gold focus:ring-ajp-gold/20"
                />
              </div>

              <div>
                <label className="block text-ajp-dark font-medium mb-2">
                  {language === 'en' ? 'Service Type' :
                   language === 'pt' ? 'Tipo de Serviço' :
                   'Tipo de Servicio'}
                </label>
                <Select value={formData.serviceType} onValueChange={(value) => handleInputChange("serviceType", value)}>
                  <SelectTrigger className="focus:border-ajp-gold focus:ring-ajp-gold/20">
                    <SelectValue placeholder={
                      language === 'en' ? 'Select service type' :
                      language === 'pt' ? 'Selecione o tipo de serviço' :
                      'Selecciona el tipo de servicio'
                    } />
                  </SelectTrigger>
                  <SelectContent>
                    {serviceTypes[language].map((service) => (
                      <SelectItem key={service.value} value={service.value}>
                        {service.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-ajp-dark font-medium mb-2">
                    {language === 'en' ? 'Preferred Date' :
                     language === 'pt' ? 'Data Preferida' :
                     'Fecha Preferida'}
                  </label>
                  <Input
                    type="date"
                    value={formData.preferredDate}
                    onChange={(e) => handleInputChange("preferredDate", e.target.value)}
                    className="focus:border-ajp-gold focus:ring-ajp-gold/20"
                    min={new Date().toISOString().split('T')[0]}
                  />
                </div>
                <div>
                  <label className="block text-ajp-dark font-medium mb-2">
                    {language === 'en' ? 'Preferred Time' :
                     language === 'pt' ? 'Horário Preferido' :
                     'Hora Preferida'}
                  </label>
                  <Select value={formData.preferredTime} onValueChange={(value) => handleInputChange("preferredTime", value)}>
                    <SelectTrigger className="focus:border-ajp-gold focus:ring-ajp-gold/20">
                      <SelectValue placeholder={
                        language === 'en' ? 'Select time' :
                        language === 'pt' ? 'Selecione horário' :
                        'Selecciona hora'
                      } />
                    </SelectTrigger>
                    <SelectContent>
                      {timeSlots.map((time) => (
                        <SelectItem key={time} value={time}>
                          {time}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="block text-ajp-dark font-medium mb-2">
                  {language === 'en' ? 'Project Address' :
                   language === 'pt' ? 'Endereço do Projeto' :
                   'Dirección del Proyecto'}
                </label>
                <Input
                  type="text"
                  placeholder={language === 'en' ? 'Project location address' :
                             language === 'pt' ? 'Endereço do local do projeto' :
                             'Dirección del lugar del proyecto'}
                  value={formData.address}
                  onChange={(e) => handleInputChange("address", e.target.value)}
                  className="focus:border-ajp-gold focus:ring-ajp-gold/20"
                />
              </div>

              <div>
                <label className="block text-ajp-dark font-medium mb-2">
                  {language === 'en' ? 'Additional Notes' :
                   language === 'pt' ? 'Observações Adicionais' :
                   'Notas Adicionales'}
                </label>
                <Textarea
                  rows={3}
                  placeholder={language === 'en' ? 'Tell us about your project...' :
                             language === 'pt' ? 'Conte-nos sobre seu projeto...' :
                             'Cuéntanos sobre tu proyecto...'}
                  value={formData.notes}
                  onChange={(e) => handleInputChange("notes", e.target.value)}
                  className="focus:border-ajp-gold focus:ring-ajp-gold/20"
                />
              </div>

              <div className="space-y-3">
                <Button
                  type="submit"
                  className="w-full bg-ajp-gold hover:bg-yellow-600 text-white py-4 text-lg font-semibold shadow-lg"
                >
                  {language === 'en' ? 'Schedule Appointment' :
                   language === 'pt' ? 'Agendar Consulta' :
                   'Programar Cita'}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full border-green-500 text-green-600 hover:bg-green-50 py-4 text-lg font-semibold"
                  onClick={() => window.open(`https://wa.me/13059757657?text=${encodeURIComponent(
                    language === 'en' ? 'Hello, I would like to schedule a consultation with AJP Services.' :
                    language === 'pt' ? 'Olá, gostaria de agendar uma consulta com a AJP Services.' :
                    'Hola, me gustaría programar una consulta con AJP Services.'
                  )}`, '_blank')}
                >
                  <MessageCircle className="w-5 h-5 mr-2" />
                  {t('contact.form.whatsapp')}
                </Button>
              </div>
            </form>
          </div>

          {/* Info Side */}
          <div className="space-y-8">
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <h3 className="text-2xl font-semibold text-ajp-dark mb-6">
                {language === 'en' ? 'What to Expect' :
                 language === 'pt' ? 'O que Esperar' :
                 'Qué Esperar'}
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-ajp-gold/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Clock className="w-6 h-6 text-ajp-gold" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-ajp-dark mb-1">
                      {language === 'en' ? 'Duration: 45-60 minutes' :
                       language === 'pt' ? 'Duração: 45-60 minutos' :
                       'Duración: 45-60 minutos'}
                    </h4>
                    <p className="text-ajp-gray text-sm">
                      {language === 'en' ? 'Comprehensive evaluation of your space and needs' :
                       language === 'pt' ? 'Avaliação abrangente do seu espaço e necessidades' :
                       'Evaluación integral de tu espacio y necesidades'}
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-ajp-gold/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-ajp-gold" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-ajp-dark mb-1">
                      {language === 'en' ? 'On-site Visit' :
                       language === 'pt' ? 'Visita no Local' :
                       'Visita en Sitio'}
                    </h4>
                    <p className="text-ajp-gray text-sm">
                      {language === 'en' ? 'We come to your location for accurate measurements' :
                       language === 'pt' ? 'Vamos ao seu local para medições precisas' :
                       'Vamos a tu ubicación para mediciones precisas'}
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-ajp-gold/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-ajp-gold" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-ajp-dark mb-1">
                      {language === 'en' ? 'Follow-up Quote' :
                       language === 'pt' ? 'Orçamento de Acompanhamento' :
                       'Cotización de Seguimiento'}
                    </h4>
                    <p className="text-ajp-gray text-sm">
                      {language === 'en' ? 'Detailed proposal within 24-48 hours' :
                       language === 'pt' ? 'Proposta detalhada em 24-48 horas' :
                       'Propuesta detallada en 24-48 horas'}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-ajp-gold/10 p-6 rounded-xl">
              <h4 className="font-semibold text-ajp-dark mb-3">
                {language === 'en' ? 'Free Consultation Includes:' :
                 language === 'pt' ? 'Consulta Gratuita Inclui:' :
                 'Consulta Gratuita Incluye:'}
              </h4>
              <ul className="space-y-2 text-ajp-gray">
                <li>• {language === 'en' ? 'Professional site evaluation' :
                         language === 'pt' ? 'Avaliação profissional do local' :
                         'Evaluación profesional del sitio'}</li>
                <li>• {language === 'en' ? 'Material recommendations' :
                         language === 'pt' ? 'Recomendações de materiais' :
                         'Recomendaciones de materiales'}</li>
                <li>• {language === 'en' ? 'Design suggestions' :
                         language === 'pt' ? 'Sugestões de design' :
                         'Sugerencias de diseño'}</li>
                <li>• {language === 'en' ? 'Preliminary timeline estimate' :
                         language === 'pt' ? 'Estimativa preliminar de cronograma' :
                         'Estimación preliminar de cronograma'}</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}