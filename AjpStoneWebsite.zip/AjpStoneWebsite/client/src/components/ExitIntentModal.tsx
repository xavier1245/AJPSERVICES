import { useState, useEffect } from 'react';
import { X, Phone, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { trackBusinessEvent } from '@/lib/analytics';

export function ExitIntentModal() {
  const [isVisible, setIsVisible] = useState(false);
  const [hasShown, setHasShown] = useState(false);
  const { language, t } = useLanguage();

  useEffect(() => {
    // Check if modal has been shown in this session
    const modalShown = sessionStorage.getItem('exitIntentModalShown');
    if (modalShown) {
      setHasShown(true);
      return;
    }

    let timeout: NodeJS.Timeout;

    const handleMouseLeave = (e: MouseEvent) => {
      // Only trigger if mouse leaves from the top of the page and user has been on site for a while
      if (e.clientY <= 0 && !hasShown && e.relatedTarget === null) {
        // Additional check: user must have scrolled at least 30% of the page
        const scrollPercentage = (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100;
        if (scrollPercentage > 30) {
          setIsVisible(true);
          setHasShown(true);
          sessionStorage.setItem('exitIntentModalShown', 'true');
          trackBusinessEvent('exit_intent_triggered');
        }
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      // Trigger on Alt+Tab or Ctrl+W (common exit patterns)
      if ((e.altKey && e.key === 'Tab') || (e.ctrlKey && e.key === 'w')) {
        if (!hasShown) {
          setIsVisible(true);
          setHasShown(true);
          sessionStorage.setItem('exitIntentModalShown', 'true');
          trackBusinessEvent('exit_intent_triggered');
        }
      }
    };

    // Add significant delay before enabling exit intent
    timeout = setTimeout(() => {
      document.addEventListener('mouseleave', handleMouseLeave);
      document.addEventListener('keydown', handleKeyDown);
    }, 45000); // Wait 45 seconds before enabling

    return () => {
      clearTimeout(timeout);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [hasShown]);

  const handleClose = () => {
    setIsVisible(false);
    trackBusinessEvent('exit_intent_closed');
  };

  const handleWhatsApp = () => {
    const message = language === 'en' 
      ? 'Hello! I am interested in getting a quote for a construction project with AJP Services.'
      : language === 'pt'
      ? 'Olá! Tenho interesse em obter um orçamento para um projeto de construção com a AJP Services.'
      : '¡Hola! Me interesa obtener una cotización para un proyecto de construcción con AJP Services.';
    
    window.open(`https://wa.me/13059757657?text=${encodeURIComponent(message)}`, '_blank');
    trackBusinessEvent('whatsapp_click');
    setIsVisible(false);
  };

  const handleCall = () => {
    window.open('tel:+13059757657');
    trackBusinessEvent('phone_click');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  const getContent = () => {
    switch (language) {
      case 'en':
        return {
          title: "Wait! Don't Leave Yet! 🏗️",
          subtitle: "Get your FREE quote in less than 24 hours",
          description: "Join hundreds of satisfied clients who transformed their spaces with premium marble, quartz, and granite installations.",
          cta: "Get My Free Quote",
          contact: "Or contact us directly:",
          whatsapp: "WhatsApp Now",
          call: "Call Now"
        };
      case 'pt':
        return {
          title: "Espere! Não Saia Ainda! 🏗️",
          subtitle: "Obtenha seu orçamento GRATUITO em menos de 24 horas",
          description: "Junte-se a centenas de clientes satisfeitos que transformaram seus espaços com instalações premium de mármore, quartzo e granito.",
          cta: "Obter Meu Orçamento Gratuito",
          contact: "Ou entre em contato diretamente:",
          whatsapp: "WhatsApp Agora",
          call: "Ligar Agora"
        };
      default:
        return {
          title: "¡Espera! ¡No Te Vayas Aún! 🏗️",
          subtitle: "Obtén tu cotización GRATUITA en menos de 24 horas",
          description: "Únete a cientos de clientes satisfechos que transformaron sus espacios con instalaciones premium de mármol, cuarzo y granito.",
          cta: "Obtener Mi Cotización Gratuita",
          contact: "O contáctanos directamente:",
          whatsapp: "WhatsApp Ahora",
          call: "Llamar Ahora"
        };
    }
  };

  const content = getContent();

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-40 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full relative animate-in zoom-in-95 duration-300">
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors"
        >
          <X className="w-6 h-6" />
        </button>
        
        <div className="p-8">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold text-ajp-dark mb-2">
              {content.title}
            </h2>
            <p className="text-ajp-gold text-lg font-semibold mb-3">
              {content.subtitle}
            </p>
            <p className="text-gray-600 text-sm leading-relaxed">
              {content.description}
            </p>
          </div>

          <div className="space-y-4">
            <Button
              onClick={() => {
                document.getElementById('contacto')?.scrollIntoView({ behavior: 'smooth' });
                setIsVisible(false);
                trackBusinessEvent('exit_intent_cta_click');
              }}
              className="w-full bg-ajp-gold hover:bg-yellow-600 text-white font-semibold py-3 text-lg"
            >
              {content.cta}
            </Button>

            <div className="text-center">
              <p className="text-sm text-gray-500 mb-3">{content.contact}</p>
              <div className="flex gap-3">
                <Button
                  onClick={handleWhatsApp}
                  variant="outline"
                  className="flex-1 border-green-500 text-green-600 hover:bg-green-50"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  {content.whatsapp}
                </Button>
                <Button
                  onClick={handleCall}
                  variant="outline"
                  className="flex-1 border-blue-500 text-blue-600 hover:bg-blue-50"
                >
                  <Phone className="w-4 h-4 mr-2" />
                  {content.call}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}