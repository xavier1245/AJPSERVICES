import { useLanguage } from "@/contexts/LanguageContext";
import { CheckCircle, Users, Ruler, Truck, Wrench, Star } from "lucide-react";

const processSteps = [
  {
    icon: Users,
    titleKey: "Consulta Inicial",
    titleEn: "Initial Consultation",
    titlePt: "Consulta Inicial",
    descriptionKey: "Reunión gratuita para entender tus necesidades, estilo y presupuesto.",
    descriptionEn: "Free meeting to understand your needs, style and budget.",
    descriptionPt: "Reunião gratuita para entender suas necessidades, estilo e orçamento."
  },
  {
    icon: Ruler,
    titleKey: "Medición y Diseño",
    titleEn: "Measurement & Design",
    titlePt: "Medição e Design",
    descriptionKey: "Tomamos medidas precisas y creamos un diseño personalizado para tu espacio.",
    descriptionEn: "We take precise measurements and create a custom design for your space.",
    descriptionPt: "Tomamos medidas precisas e criamos um design personalizado para seu espaço."
  },
  {
    icon: CheckCircle,
    titleKey: "Selección de Materiales",
    titleEn: "Material Selection",
    titlePt: "Seleção de Materiais",
    descriptionKey: "Te ayudamos a elegir los mejores materiales que se adapten a tu proyecto.",
    descriptionEn: "We help you choose the best materials that fit your project.",
    descriptionPt: "Ajudamos você a escolher os melhores materiais que se adequem ao seu projeto."
  },
  {
    icon: Wrench,
    titleKey: "Fabricación Artesanal",
    titleEn: "Artisan Fabrication",
    titlePt: "Fabricação Artesanal",
    descriptionKey: "Nuestros artesanos trabajan cada pieza con precisión y cuidado excepcional.",
    descriptionEn: "Our artisans work each piece with precision and exceptional care.",
    descriptionPt: "Nossos artesãos trabalham cada peça com precisão e cuidado excepcional."
  },
  {
    icon: Truck,
    titleKey: "Instalación Profesional",
    titleEn: "Professional Installation",
    titlePt: "Instalação Profissional",
    descriptionKey: "Instalamos tu proyecto con técnicas profesionales y atención al detalle.",
    descriptionEn: "We install your project with professional techniques and attention to detail.",
    descriptionPt: "Instalamos seu projeto com técnicas profissionais e atenção aos detalhes."
  },
  {
    icon: Star,
    titleKey: "Entrega Final",
    titleEn: "Final Delivery",
    titlePt: "Entrega Final",
    descriptionKey: "Inspección final y entrega de tu espacio transformado con garantía completa.",
    descriptionEn: "Final inspection and delivery of your transformed space with full warranty.",
    descriptionPt: "Inspeção final e entrega do seu espaço transformado com garantia completa."
  }
];

export default function Process() {
  const { language, t } = useLanguage();

  const getTitle = (step: typeof processSteps[0]) => {
    switch(language) {
      case 'en': return step.titleEn;
      case 'pt': return step.titlePt;
      default: return step.titleKey;
    }
  };

  const getDescription = (step: typeof processSteps[0]) => {
    switch(language) {
      case 'en': return step.descriptionEn;
      case 'pt': return step.descriptionPt;
      default: return step.descriptionKey;
    }
  };

  return (
    <section id="proceso" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-ajp-dark mb-4">
            {t('process.title')}
          </h2>
          <p className="text-xl text-ajp-gray max-w-3xl mx-auto">
            {t('process.subtitle')}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {processSteps.map((step, index) => {
            const IconComponent = step.icon;
            return (
              <div
                key={index}
                className="relative bg-gray-50 p-8 rounded-xl hover:shadow-xl transition-shadow group"
              >
                <div className="absolute -top-4 left-8">
                  <div className="w-8 h-8 bg-ajp-gold rounded-full flex items-center justify-center text-white font-bold text-sm">
                    {index + 1}
                  </div>
                </div>
                
                <div className="w-16 h-16 bg-ajp-gold/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-ajp-gold/20 transition-colors">
                  <IconComponent className="w-8 h-8 text-ajp-gold" />
                </div>
                
                <h3 className="text-xl font-semibold text-ajp-dark mb-4">
                  {getTitle(step)}
                </h3>
                
                <p className="text-ajp-gray">
                  {getDescription(step)}
                </p>
              </div>
            );
          })}
        </div>

        <div className="text-center mt-12">
          <div className="bg-ajp-gold/10 rounded-xl p-8 max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-ajp-dark mb-4">
              {language === 'en' ? 'Ready to start your project?' : 
               language === 'pt' ? 'Pronto para começar seu projeto?' : 
               '¿Listo para comenzar tu proyecto?'}
            </h3>
            <p className="text-ajp-gray mb-6">
              {language === 'en' ? 'Contact us today for a free consultation and personalized quote.' :
               language === 'pt' ? 'Entre em contato conosco hoje para uma consulta gratuita e orçamento personalizado.' :
               'Contáctanos hoy para una consulta gratuita y cotización personalizada.'}
            </p>
            <button
              onClick={() => {
                const appointmentSection = document.getElementById('cita');
                if (appointmentSection) {
                  appointmentSection.scrollIntoView({ behavior: 'smooth' });
                }
              }}
              className="bg-ajp-gold hover:bg-yellow-600 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors shadow-lg"
            >
              {language === 'en' ? 'Schedule Appointment' :
               language === 'pt' ? 'Agendar Consulta' :
               'Programar Cita'}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}