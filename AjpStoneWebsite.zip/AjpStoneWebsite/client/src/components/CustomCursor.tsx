import { useState, useEffect } from 'react';

interface CursorPosition {
  x: number;
  y: number;
}

export function CustomCursor() {
  const [position, setPosition] = useState<CursorPosition>({ x: 0, y: 0 });
  const [isHovering, setIsHovering] = useState(false);
  const [isClicking, setIsClicking] = useState(false);

  useEffect(() => {
    const updatePosition = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
    };

    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      
      // Check if mouse is over header
      const header = document.querySelector('header');
      if (header && header.contains(target)) {
        setIsHovering(false);
        return;
      }
      
      // Simple but comprehensive check
      let isInteractive = false;
      let currentElement: HTMLElement | null = target;
      
      // Check up to 5 levels of parent elements
      for (let i = 0; i < 5 && currentElement && currentElement !== document.body; i++) {
        // Check if it's a button or link
        if (currentElement.tagName === 'BUTTON' || currentElement.tagName === 'A') {
          isInteractive = true;
          break;
        }
        
        // Check data-interactive attribute
        if (currentElement.hasAttribute('data-interactive')) {
          isInteractive = true;
          break;
        }
        
        // Check for click handlers
        if (currentElement.onclick || currentElement.getAttribute('onclick')) {
          isInteractive = true;
          break;
        }
        
        // Check CSS cursor
        const computedStyle = getComputedStyle(currentElement);
        if (computedStyle.cursor === 'pointer') {
          isInteractive = true;
          break;
        }
        
        // Check for common interactive classes
        const classList = Array.from(currentElement.classList);
        if (classList.some(cls => 
          cls.includes('hover:') || 
          cls.includes('cursor-pointer') ||
          cls.includes('transition-colors') ||
          cls === 'group'
        )) {
          isInteractive = true;
          break;
        }
        
        currentElement = currentElement.parentElement;
      }
      
      // Debug logging in development
      if (process.env.NODE_ENV === 'development' && isInteractive !== isHovering) {
        console.log('Cursor state change:', { 
          element: target.tagName, 
          classes: Array.from(target.classList), 
          isInteractive,
          hasDataInteractive: target.hasAttribute('data-interactive') || target.closest('[data-interactive]')
        });
      }
      
      setIsHovering(isInteractive);
    };

    const handleMouseDown = () => setIsClicking(true);
    const handleMouseUp = () => setIsClicking(false);

    document.addEventListener('mousemove', updatePosition);
    document.addEventListener('mouseover', handleMouseOver);
    document.addEventListener('mousedown', handleMouseDown);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', updatePosition);
      document.removeEventListener('mouseover', handleMouseOver);
      document.removeEventListener('mousedown', handleMouseDown);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  // Don't show custom cursor on mobile devices or touch devices
  const isMobile = /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
  
  if (isMobile || isTouchDevice) return null;

  return (
    <>
      {/* Main cursor */}
      <div
        id="custom-cursor"
        className={`fixed top-0 left-0 w-6 h-6 pointer-events-none z-40 transition-all duration-200 ease-out ${
          isClicking ? 'scale-75' : isHovering ? 'scale-150' : 'scale-100'
        }`}
        style={{
          transform: `translate(${position.x - 12}px, ${position.y - 12}px) scale(${
            isClicking ? 0.75 : isHovering ? 1.5 : 1
          })`,
          background: isHovering 
            ? 'linear-gradient(45deg, #D4AF37, #FFD700)' 
            : 'rgba(212, 175, 55, 0.8)',
          borderRadius: '50%',
          boxShadow: isHovering 
            ? '0 0 20px rgba(212, 175, 55, 0.6)' 
            : '0 0 10px rgba(212, 175, 55, 0.4)',
        }}
      />
      
      {/* Trailing dot */}
      <div
        className="fixed top-0 left-0 w-2 h-2 pointer-events-none z-40 transition-all duration-500 ease-out"
        style={{
          transform: `translate(${position.x - 4}px, ${position.y - 4}px)`,
          background: 'rgba(212, 175, 55, 0.3)',
          borderRadius: '50%',
          transitionDelay: '50ms'
        }}
      />
    </>
  );
}