export function SchemaMarkup() {
  const businessSchema = {
    "@context": "https://schema.org",
    "@type": "HomeAndConstructionBusiness",
    "name": "AJP Stone & Services",
    "description": "Especialistas en mármol, cuarzo, granito y porcelanato de alta gama en Miami. Transformamos espacios con la más fina artesanía.",
    "image": "http://ajp-services.com/wp-content/uploads/2021/08/ajpservices.png",
    "url": "https://ajp-services.com",
    "telephone": "+1-305-975-7657",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Miami",
      "addressLocality": "Miami",
      "addressRegion": "FL",
      "postalCode": "33101",
      "addressCountry": "US"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": 25.7617,
      "longitude": -80.1918
    },
    "openingHours": [
      "Mo-Fr 08:00-18:00",
      "Sa 09:00-16:00"
    ],
    "serviceArea": {
      "@type": "GeoCircle",
      "geoMidpoint": {
        "@type": "GeoCoordinates",
        "latitude": 25.7617,
        "longitude": -80.1918
      },
      "geoRadius": "50"
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "5.0",
      "reviewCount": "150"
    },
    "priceRange": "$$-$$$",
    "paymentAccepted": "Cash, Credit Card",
    "hasOfferCatalog": {
      "@type": "OfferCatalog",
      "name": "Construction Services",
      "itemListElement": [
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "Marble Installation",
            "description": "Premium marble installation for kitchens, bathrooms and luxury areas"
          }
        },
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "Quartz Countertops",
            "description": "Engineered quartz surfaces with exceptional durability and unique designs"
          }
        },
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "Granite Installation",
            "description": "Natural granite with unique patterns and superior resistance"
          }
        },
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "Porcelain Surfaces",
            "description": "Technical large format porcelain with natural stone appearance"
          }
        }
      ]
    }
  };

  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "AJP Stone & Services",
    "alternateName": "AJP Services",
    "url": "https://ajp-services.com",
    "logo": "http://ajp-services.com/wp-content/uploads/2021/08/ajpservices.png",
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+1-305-975-7657",
      "contactType": "customer service",
      "availableLanguage": ["English", "Spanish", "Portuguese"]
    },
    "sameAs": [
      "https://www.instagram.com/ajpservices_",
      "https://wa.me/13059757657"
    ]
  };

  const websiteSchema = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": "AJP Stone & Services",
    "url": "https://ajp-services.com",
    "potentialAction": {
      "@type": "SearchAction",
      "target": "https://ajp-services.com/search?q={search_term_string}",
      "query-input": "required name=search_term_string"
    }
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(businessSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }}
      />
    </>
  );
}