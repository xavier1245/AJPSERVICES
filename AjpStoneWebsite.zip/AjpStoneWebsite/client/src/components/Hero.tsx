import { useLanguage } from "../contexts/LanguageContext";

export default function Hero() {
  const { t } = useLanguage();
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerHeight = 80;
      const targetPosition = element.offsetTop - headerHeight;
      window.scrollTo({
        top: targetPosition,
        behavior: "smooth",
      });
    }
  };

  return (
    <section
      id="inicio"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Marble background texture */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage:
            "url('https://ajp-services.com/wp-content/uploads/2024/05/4A3E1656-809F-4B14-AF67-EC91455BE5F3-scaled-1.jpeg')",
        }}
      />
      <div className="absolute inset-0 bg-black/50" />

      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
          {t('hero.title')} <span className="text-ajp-gold">{t('hero.title.highlight')}</span>
        </h1>
        <p className="text-xl md:text-2xl text-gray-200 mb-8 max-w-2xl mx-auto">
          {t('hero.subtitle')}
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={() => scrollToSection("contacto")}
            className="bg-ajp-gold hover:bg-yellow-600 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors shadow-lg"
          >
            {t('hero.cta.quote')}
          </button>
          <button
            onClick={() => scrollToSection("proyectos")}
            className="border-2 border-white text-white hover:bg-white hover:text-ajp-dark px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
          >
            {t('hero.cta.projects')}
          </button>
        </div>
      </div>
    </section>
  );
}
