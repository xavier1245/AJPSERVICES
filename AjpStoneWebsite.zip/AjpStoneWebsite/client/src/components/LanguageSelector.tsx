import { useLanguage } from "@/contexts/LanguageContext";
import { Wrench } from "lucide-react";

export default function LanguageSelector() {
  const { language, setLanguage } = useLanguage();

  const languages = [
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'pt', name: 'Português', flag: '🇧🇷' }
  ];

  return (
    <div className="relative group">
      <button className="flex items-center space-x-2 text-ajp-dark hover:text-ajp-gold active:scale-95 transition-all duration-150 cursor-pointer px-3 py-2 rounded-lg" data-interactive="true">
        <Wrench className="w-5 h-5 text-ajp-gold" />
        <span className="hidden md:inline font-medium">
          {languages.find(l => l.code === language)?.name}
        </span>
      </button>
      
      <div className="absolute right-0 top-full mt-2 bg-white rounded-lg shadow-lg border min-w-[150px] opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
        {languages.map((lang) => (
          <button
            key={lang.code}
            onClick={() => {
              setLanguage(lang.code as 'es' | 'en' | 'pt');
              // Track language change
              import('@/lib/analytics').then(({ trackBusinessEvent }) => {
                trackBusinessEvent('language_change', lang.code);
              });
            }}
            className={`w-full flex items-center space-x-3 px-4 py-2 text-left hover:bg-gray-50 first:rounded-t-lg last:rounded-b-lg transition-colors cursor-pointer ${
              language === lang.code ? 'bg-ajp-gold/10 text-ajp-gold' : 'text-ajp-dark'
            }`}
            data-interactive="true"
          >
            <span className="text-lg">{lang.flag}</span>
            <span className="font-medium">{lang.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}