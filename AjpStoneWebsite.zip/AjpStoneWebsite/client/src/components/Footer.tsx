import { Facebook, Instagram, Linkedin, MessageCircle } from "lucide-react";

export default function Footer() {
  const services = [
    "Instalación de Mármol",
    "Encimeras de Cuarzo",
    "Pisos de Granito",
    "Porcelanato Técnico",
    "Diseño Personalizado",
  ];

  const socialLinks = [
    { icon: Facebook, href: "https://www.facebook.com/ajpservices", label: "Facebook" },
    { icon: Instagram, href: "https://instagram.com/ajpservices_", label: "Instagram" },
    { icon: Linkedin, href: "https://www.linkedin.com/company/ajp-services", label: "LinkedIn" },
    { icon: MessageCircle, href: "https://wa.me/13059757657", label: "WhatsApp" },
  ];

  return (
    <footer className="bg-ajp-dark text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-20 h-12 bg-white rounded-lg p-2 flex items-center justify-center">
                <img 
                  src="http://ajp-services.com/wp-content/uploads/2021/08/ajpservices.png" 
                  alt="AJP Services Logo" 
                  className="h-8 w-auto object-contain"
                />
              </div>
              <div>
                <div className="text-white font-semibold text-lg">
                  AJP Stone & Services
                </div>
                <div className="text-gray-400 text-sm">
                  Construcción de Alta Gama
                </div>
              </div>
            </div>
            <p className="text-gray-400 mb-4 max-w-md">
              Especialistas en mármol, cuarzo, granito y porcelanato de alta gama
              en Miami. Transformamos espacios con la más fina artesanía y
              materiales de primera calidad.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social, index) => {
                const IconComponent = social.icon;
                return (
                  <a
                    key={index}
                    href={social.href}
                    aria-label={social.label}
                    className="w-10 h-10 bg-gray-700 hover:bg-ajp-gold rounded-lg flex items-center justify-center transition-colors"
                  >
                    <IconComponent className="w-5 h-5" />
                  </a>
                );
              })}
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-4">Servicios</h4>
            <ul className="space-y-2 text-gray-400">
              {services.map((service, index) => (
                <li key={index}>
                  <a
                    href="#"
                    className="hover:text-ajp-gold transition-colors"
                  >
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-4">Contacto</h4>
            <ul className="space-y-2 text-gray-400">
              <li>1234 Brickell Avenue</li>
              <li>Miami, FL 33131</li>
              <li>(305) 975-7657</li>
              <li>info@ajpstone.com</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 AJP Stone & AJP Services. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
