import { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'es' | 'en' | 'pt';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  es: {
    // Header
    'nav.home': 'Inicio',
    'nav.services': 'Servicios',
    'nav.projects': 'Proyectos',
    'nav.process': 'Proceso',
    'nav.appointment': 'Cita',
    'nav.contact': 'Contacto',

    // Hero
    'hero.title': 'Elegancia en',
    'hero.title.highlight': 'Piedra',
    'hero.subtitle': 'Especialistas en mármol, cuarzo, granito y porcelanato de alta gama en Miami. Transformamos espacios con la más fina artesanía.',
    'hero.cta.quote': 'Solicitar Cotización',
    'hero.cta.projects': 'Ver Proyectos',

    // Services
    'services.title': 'Nuestros Servicios',
    'services.subtitle': 'Ofrecemos una gama completa de servicios especializados en piedras naturales y materiales de alta gama para proyectos residenciales y comerciales.',
    'services.marble.title': 'Mármol',
    'services.marble.desc': 'Instalación de mármol de la más alta calidad para cocinas, baños y áreas de lujo.',
    'services.quartz.title': 'Cuarzo',
    'services.quartz.desc': 'Superficies de cuarzo de ingeniería con durabilidad excepcional y diseños únicos.',
    'services.granite.title': 'Granito',
    'services.granite.desc': 'Granito natural con patrones únicos y resistencia superior para proyectos duraderos.',
    'services.porcelain.title': 'Porcelanato',
    'services.porcelain.desc': 'Porcelanato técnico de gran formato con apariencia de piedra natural y máxima durabilidad.',

    // Projects
    'projects.title': 'Proyectos Destacados',
    'projects.subtitle': 'Descubre algunos de nuestros trabajos más representativos en residencias y proyectos comerciales de lujo en Miami.',
    'projects.viewAll': 'Ver Todos los Proyectos',
    'projects.viewDetails': 'Ver Detalles',

    // Process
    'process.title': 'Nuestro Proceso de Trabajo',
    'process.subtitle': 'Un enfoque profesional y sistemático que garantiza resultados excepcionales en cada proyecto.',

    // Appointment
    'appointment.title': 'Programa tu Cita',
    'appointment.subtitle': 'Agenda una consulta gratuita con nuestros expertos para evaluar tu proyecto.',

    // Contact
    'contact.title': 'Contáctanos',
    'contact.subtitle': 'Estamos listos para transformar tu espacio con los mejores materiales y la más fina artesanía. Solicita tu cotización personalizada.',
    'contact.form.title': 'Solicita tu Cotización',
    'contact.form.name': 'Nombre',
    'contact.form.phone': 'Teléfono',
    'contact.form.email': 'Email',
    'contact.form.projectType': 'Tipo de Proyecto',
    'contact.form.message': 'Mensaje',
    'contact.form.submit': 'Enviar Solicitud',
    'contact.form.whatsapp': 'Contactar por WhatsApp',
    'contact.info.title': 'Información de Contacto',
    'contact.why.title': '¿Por qué elegirnos?',
    'contact.address.title': 'Dirección',
    'contact.phone.title': 'Teléfono',
    'contact.email.title': 'Email',
    'contact.hours.title': 'Horarios',
    'contact.hours.content': 'Lunes - Viernes: 8:00 AM - 6:00 PM\nSábados: 9:00 AM - 4:00 PM\nDomingos: Cerrado',
    'contact.benefit.1': '+15 años de experiencia en Miami',
    'contact.benefit.2': 'Materiales de la más alta calidad',
    'contact.benefit.3': 'Instalación profesional certificada',
    'contact.benefit.4': 'Garantía completa en todos nuestros trabajos',

    // Footer
    'footer.services': 'Servicios',
    'footer.contact': 'Contacto',
    'footer.rights': 'Todos los derechos reservados.',

    // Common
    'common.loading': 'Cargando...',
    'common.close': 'Cerrar',
    'common.back': 'Volver',

    // Project Translations

    'project.3.title': 'Remodelación Casa Completa',
    'project.3.desc': 'Proyecto integral con múltiples superficies de piedra natural.',
    'project.4.title': 'Panadería Comercial',
    'project.4.desc': 'Instalación comercial con superficies resistentes y diseño funcional.',
    'project.5.title': 'Cocina Residencial Elegante',
    'project.5.desc': 'Encimeras de granito con backsplash personalizado y acabados premium.',

    'project.7.title': 'Tienda Comercial Premium',
    'project.7.desc': 'Proyecto comercial con diseño elegante y materiales de alta resistencia.',
    'project.8.title': 'Cocina Moderna con Isla',
    'project.8.desc': 'Cocina contemporánea con isla central de cuarzo y diseño funcional.',
    'project.9.title': 'Baño Spa Residencial',
    'project.9.desc': 'Baño de lujo con diseño spa, mármol natural y acabados premium.',
    'project.10.title': 'Encimera Vertical Premium',
    'project.10.desc': 'Instalación de encimera vertical con mármol de alta calidad y acabados artesanales.',
    'project.11.title': 'Proyecto Comercial Elegante',
    'project.11.desc': 'Diseño comercial sofisticado con granito premium y acabados de lujo.',
  },
  en: {
    // Header
    'nav.home': 'Home',
    'nav.services': 'Services',
    'nav.projects': 'Projects',
    'nav.process': 'Process',
    'nav.appointment': 'Appointment',
    'nav.contact': 'Contact',

    // Hero
    'hero.title': 'Elegance in',
    'hero.title.highlight': 'Stone',
    'hero.subtitle': 'Specialists in high-end marble, quartz, granite and porcelain in Miami. We transform spaces with the finest craftsmanship.',
    'hero.cta.quote': 'Request Quote',
    'hero.cta.projects': 'View Projects',

    // Services
    'services.title': 'Our Services',
    'services.subtitle': 'We offer a complete range of specialized services in natural stones and high-end materials for residential and commercial projects.',
    'services.marble.title': 'Marble',
    'services.marble.desc': 'Installation of the highest quality marble for kitchens, bathrooms and luxury areas.',
    'services.quartz.title': 'Quartz',
    'services.quartz.desc': 'Engineered quartz surfaces with exceptional durability and unique designs.',
    'services.granite.title': 'Granite',
    'services.granite.desc': 'Natural granite with unique patterns and superior resistance for durable projects.',
    'services.porcelain.title': 'Porcelain',
    'services.porcelain.desc': 'Technical large format porcelain with natural stone appearance and maximum durability.',

    // Projects
    'projects.title': 'Featured Projects',
    'projects.subtitle': 'Discover some of our most representative work in luxury residences and commercial projects in Miami.',
    'projects.viewAll': 'View All Projects',
    'projects.viewDetails': 'View Details',

    // Process
    'process.title': 'Our Work Process',
    'process.subtitle': 'A professional and systematic approach that guarantees exceptional results in every project.',

    // Appointment
    'appointment.title': 'Schedule Your Appointment',
    'appointment.subtitle': 'Book a free consultation with our experts to evaluate your project.',

    // Contact
    'contact.title': 'Contact Us',
    'contact.subtitle': 'We are ready to transform your space with the best materials and finest craftsmanship. Request your personalized quote.',
    'contact.form.title': 'Request Your Quote',
    'contact.form.name': 'Name',
    'contact.form.phone': 'Phone',
    'contact.form.email': 'Email',
    'contact.form.projectType': 'Project Type',
    'contact.form.message': 'Message',
    'contact.form.submit': 'Send Request',
    'contact.form.whatsapp': 'Contact via WhatsApp',
    'contact.info.title': 'Contact Information',
    'contact.why.title': 'Why choose us?',
    'contact.address.title': 'Address',
    'contact.phone.title': 'Phone',
    'contact.email.title': 'Email',
    'contact.hours.title': 'Hours',
    'contact.hours.content': 'Monday - Friday: 8:00 AM - 6:00 PM\nSaturdays: 9:00 AM - 4:00 PM\nSundays: Closed',
    'contact.benefit.1': '+15 years of experience in Miami',
    'contact.benefit.2': 'Highest quality materials',
    'contact.benefit.3': 'Certified professional installation',
    'contact.benefit.4': 'Complete warranty on all our work',

    // Footer
    'footer.services': 'Services',
    'footer.contact': 'Contact',
    'footer.rights': 'All rights reserved.',

    // Common
    'common.loading': 'Loading...',
    'common.close': 'Close',
    'common.back': 'Back',

    // Project Translations

    'project.3.title': 'Complete House Remodel',
    'project.3.desc': 'Integral project with multiple natural stone surfaces.',
    'project.4.title': 'Commercial Bakery',
    'project.4.desc': 'Commercial installation with resistant surfaces and functional design.',
    'project.5.title': 'Elegant Residential Kitchen',
    'project.5.desc': 'Granite countertops with custom backsplash and premium finishes.',

    'project.7.title': 'Premium Commercial Store',
    'project.7.desc': 'Commercial project with elegant design and high-resistance materials.',
    'project.8.title': 'Modern Kitchen with Island',
    'project.8.desc': 'Contemporary kitchen with quartz central island and functional design.',
    'project.9.title': 'Residential Spa Bathroom',
    'project.9.desc': 'Luxury bathroom with spa design, natural marble and premium finishes.',
    'project.10.title': 'Premium Vertical Countertop',
    'project.10.desc': 'Vertical countertop installation with high-quality marble and artisanal finishes.',
    'project.11.title': 'Elegant Commercial Project',
    'project.11.desc': 'Sophisticated commercial design with premium granite and luxury finishes.',
  },
  pt: {
    // Header
    'nav.home': 'Início',
    'nav.services': 'Serviços',
    'nav.projects': 'Projetos',
    'nav.process': 'Processo',
    'nav.appointment': 'Consulta',
    'nav.contact': 'Contato',

    // Hero
    'hero.title': 'Elegância em',
    'hero.title.highlight': 'Pedra',
    'hero.subtitle': 'Especialistas em mármore, quartzo, granito e porcelanato de alta qualidade em Miami. Transformamos espaços com o mais fino artesanato.',
    'hero.cta.quote': 'Solicitar Orçamento',
    'hero.cta.projects': 'Ver Projetos',

    // Services
    'services.title': 'Nossos Serviços',
    'services.subtitle': 'Oferecemos uma gama completa de serviços especializados em pedras naturais e materiais de alta qualidade para projetos residenciais e comerciais.',
    'services.marble.title': 'Mármore',
    'services.marble.desc': 'Instalação de mármore da mais alta qualidade para cozinhas, banheiros e áreas de luxo.',
    'services.quartz.title': 'Quartzo',
    'services.quartz.desc': 'Superfícies de quartzo engenheirado com durabilidade excepcional e designs únicos.',
    'services.granite.title': 'Granito',
    'services.granite.desc': 'Granito natural com padrões únicos e resistência superior para projetos duráveis.',
    'services.porcelain.title': 'Porcelanato',
    'services.porcelain.desc': 'Porcelanato técnico de grande formato com aparência de pedra natural e máxima durabilidade.',

    // Projects
    'projects.title': 'Projetos em Destaque',
    'projects.subtitle': 'Descubra alguns dos nossos trabalhos mais representativos em residências e projetos comerciais de luxo em Miami.',
    'projects.viewAll': 'Ver Todos os Projetos',
    'projects.viewDetails': 'Ver Detalhes',

    // Process
    'process.title': 'Nosso Processo de Trabalho',
    'process.subtitle': 'Uma abordagem profissional e sistemática que garante resultados excepcionais em cada projeto.',

    // Appointment
    'appointment.title': 'Agende sua Consulta',
    'appointment.subtitle': 'Marque uma consulta gratuita com nossos especialistas para avaliar seu projeto.',

    // Contact
    'contact.title': 'Entre em Contato',
    'contact.subtitle': 'Estamos prontos para transformar seu espaço com os melhores materiais e o mais fino artesanato. Solicite seu orçamento personalizado.',
    'contact.form.title': 'Solicite seu Orçamento',
    'contact.form.name': 'Nome',
    'contact.form.phone': 'Telefone',
    'contact.form.email': 'Email',
    'contact.form.projectType': 'Tipo de Projeto',
    'contact.form.message': 'Mensagem',
    'contact.form.submit': 'Enviar Solicitação',
    'contact.form.whatsapp': 'Contatar via WhatsApp',
    'contact.info.title': 'Informações de Contato',
    'contact.why.title': 'Por que nos escolher?',
    'contact.address.title': 'Endereço',
    'contact.phone.title': 'Telefone',
    'contact.email.title': 'Email',
    'contact.hours.title': 'Horários',
    'contact.hours.content': 'Segunda - Sexta: 8:00 AM - 6:00 PM\nSábados: 9:00 AM - 4:00 PM\nDomingos: Fechado',
    'contact.benefit.1': '+15 anos de experiência em Miami',
    'contact.benefit.2': 'Materiais da mais alta qualidade',
    'contact.benefit.3': 'Instalação profissional certificada',
    'contact.benefit.4': 'Garantia completa em todos os nossos trabalhos',

    // Footer
    'footer.services': 'Serviços',
    'footer.contact': 'Contato',
    'footer.rights': 'Todos os direitos reservados.',

    // Common
    'common.loading': 'Carregando...',
    'common.close': 'Fechar',
    'common.back': 'Voltar',

    // Project titles and descriptions
    'project.3.title': 'Remodelação Casa Completa',
    'project.3.desc': 'Projeto integral de remodelação com múltiplos espaços e diferentes tipos de pedra natural.',
    'project.4.title': 'Padaria Comercial Downtown',
    'project.4.desc': 'Instalação comercial especializada com superfícies resistentes e cumprimento de normas sanitárias.',
    'project.7.title': 'Cozinha Moderna Completa',
    'project.7.desc': 'Cozinha moderna completa com materiais de primeira linha e design contemporâneo.',
    'project.8.title': 'Projeto Comercial Sofisticado',
    'project.8.desc': 'Instalação comercial sofisticada com quartzo de engenharia e acabamentos profissionais.',
    'project.9.title': 'Bancada Vertical Premium',
    'project.9.desc': 'Instalação de bancada vertical com mármore de alta qualidade e acabamentos artesanais.',
    'project.10.title': 'Bancada Vertical Premium',
    'project.10.desc': 'Instalação de bancada vertical com mármore de alta qualidade e acabamentos artesanais.',
    'project.11.title': 'Projeto Comercial Elegante',
    'project.11.desc': 'Design comercial sofisticado com granito premium e acabamentos de luxo.'
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguage] = useState<Language>('es');

  const t = (key: string): string => {
    const translation = translations[language];
    const result = (translation as any)[key];
    return result || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
}