# Guía de Despliegue en Vercel - AJP Stone & Services

## Pasos para Desplegar

### 1. Preparación
- El proyecto ya está configurado para Vercel con `vercel.json`
- Los archivos necesarios están listos

### 2. Crear cuenta en Vercel
1. Ve a [vercel.com](https://vercel.com)
2. Regístrate con tu cuenta de GitHub, GitLab o email

### 3. Opciones de Despliegue

#### Opción A: Desde GitHub (Recomendado)
1. Sube tu proyecto a un repositorio de GitHub
2. En Vercel, conecta tu cuenta de GitHub
3. Importa el repositorio
4. Vercel detectará automáticamente la configuración

#### Opción B: Despliegue directo
1. Instala Vercel CLI: `npm i -g vercel`
2. En la carpeta del proyecto ejecuta: `vercel`
3. Sigue las instrucciones en pantalla

### 4. Variables de Entorno
En el dashboard de Vercel, agrega estas variables:

```
VITE_GA_TRACKING_ID=tu_id_de_google_analytics
VITE_FACEBOOK_PIXEL_ID=tu_id_de_facebook_pixel
```

### 5. Dominio Personalizado (Opcional)
1. En el dashboard de Vercel, ve a tu proyecto
2. Sección "Domains"
3. Agrega tu dominio personalizado
4. Configura los DNS según las instrucciones

## Archivos Creados para Vercel

- `vercel.json` - Configuración de despliegue
- `README.md` - Documentación del proyecto
- `.env.example` - Ejemplo de variables de entorno
- `DEPLOYMENT_GUIDE.md` - Esta guía

## URL Final
Después del despliegue, tu sitio estará disponible en:
- URL temporal: `https://tu-proyecto.vercel.app`
- Con dominio personalizado: `https://tu-dominio.com`

## Notas Importantes
- El sitio es completamente estático, no requiere servidor
- Las imágenes y assets se cargan automáticamente
- El sitio funciona offline gracias al service worker
- Todas las optimizaciones SEO están incluidas